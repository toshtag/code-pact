import { readFileSync, writeFileSync, copyFileSync, existsSync, mkdirSync, rmSync, mkdtempSync } from 'node:fs';
import { execSync } from 'node:child_process';
import path from 'node:path';

const zipPath = process.argv[2] || '/tmp/P84-T2-evidence/P84-T2-evidence.zip';
const cases = [
  { name: 'tamper-token-usage', target: 'baseline/metrics.json', mutate: (s) => { const d=JSON.parse(s); d.total_tokens += 1000; return JSON.stringify(d,null,2); } },
  { name: 'tamper-model-identity', target: 'capability/response.json', mutate: (s) => { const d=JSON.parse(s); d.model = 'gemma3:latest'; return JSON.stringify(d,null,2); } },
  { name: 'tamper-oracle-passed', target: 'baseline/oracle.json', mutate: (s) => { const d=JSON.parse(s); d.final_passed = false; return JSON.stringify(d,null,2); } },
  { name: 'tamper-changed-files', target: 'baseline/changed-files.json', mutate: (s) => { const d=JSON.parse(s); d.push({path:'forbidden.ts', sha256:'abc', allowed:true}); return JSON.stringify(d,null,2); } },
];

const results = [];
for (const c of cases) {
  const tmp = mkdtempSync('/tmp/p84-t2-neg-');
  try {
    execSync(`unzip -q -o ${zipPath} -d ${tmp}`);
    const targetPath = path.join(tmp, c.target);
    const original = readFileSync(targetPath, 'utf8');
    const tampered = c.mutate(original);
    writeFileSync(targetPath, tampered);
    const outZip = `${tmp}.zip`;
    execSync(`cd ${tmp} && zip -r ${outZip} . -x ${outZip}`);
    let exit = 0, stderr = '', stdout = '';
    try {
      stdout = execSync(`node ${path.join(tmp, 'verify.mjs')} ${outZip}`, { encoding: 'utf8', stdio: 'pipe', maxBuffer: 10 * 1024 * 1024 });
    } catch (e) {
      exit = e.status || 1;
      stderr = e.stderr || e.stdout || '';
    }
    results.push({ name: c.name, target: c.target, expected_exit: 1, actual_exit: exit, passed: exit !== 0, output: (stderr || stdout).slice(0,500) });
  } finally {
    rmSync(tmp, { recursive: true, force: true });
    try { rmSync(`${tmp}.zip`, { force: true }); } catch {}
  }
}
writeFileSync('/tmp/P84-T2-evidence/negative-verification-results.json', JSON.stringify({ schema_version: 1, all_passed: results.every(r => r.passed), results }, null, 2));
console.log(JSON.stringify({ all_passed: results.every(r => r.passed), results: results.map(r => ({ name: r.name, passed: r.passed, exit: r.actual_exit })) }, null, 2));
