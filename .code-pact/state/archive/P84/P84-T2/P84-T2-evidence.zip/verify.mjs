import {
  readFileSync,
  writeFileSync,
  existsSync,
  mkdtempSync,
  rmSync,
  readdirSync,
  statSync,
} from "node:fs";
import { createHash } from "node:crypto";
import { execSync } from "node:child_process";
import path from "node:path";

const zipPath = process.argv[2];
if (!zipPath) {
  console.error("usage: node verify.mjs <evidence.zip> [--self-test]");
  process.exit(2);
}

const tmp = mkdtempSync("/tmp/p84-t2-verify-");
try {
  execSync(`unzip -q -o ${zipPath} -d ${tmp}`);
  const root = tmp;
  const errors = [];
  const warnings = [];

  function fail(msg) {
    errors.push(msg);
    console.error("FAIL:", msg);
  }
  function warn(msg) {
    warnings.push(msg);
    console.error("WARN:", msg);
  }

  // manifest and hashes
  const manifest = JSON.parse(
    readFileSync(path.join(root, "manifest.json"), "utf8"),
  );
  const hashes = JSON.parse(
    readFileSync(path.join(root, "hashes.json"), "utf8"),
  );
  for (const f of manifest.files) {
    if (!existsSync(path.join(root, f))) {
      fail(`missing file: ${f}`);
      continue;
    }
    const h = createHash("sha256");
    h.update(readFileSync(path.join(root, f)));
    const actual = h.digest("hex");
    if (hashes[f] !== actual) fail(`hash mismatch: ${f}`);
  }

  const env = JSON.parse(
    readFileSync(path.join(root, "environment.json"), "utf8"),
  );
  const facts = JSON.parse(
    readFileSync(path.join(root, "canonical-task-facts.json"), "utf8"),
  );

  // model identity equality across all model responses
  const capResp = JSON.parse(
    readFileSync(path.join(root, "capability/response.json"), "utf8"),
  );
  const capMetrics = JSON.parse(
    readFileSync(path.join(root, "capability/metrics.json"), "utf8"),
  );
  const baseMetrics = JSON.parse(
    readFileSync(path.join(root, "baseline/metrics.json"), "utf8"),
  );
  const cpMetrics = JSON.parse(
    readFileSync(path.join(root, "code-pact/metrics.json"), "utf8"),
  );
  const capModel = capResp.model || capMetrics.model || env.model_name;
  const baseModel = baseMetrics.model || env.model_name;
  const cpModel = cpMetrics.model || env.model_name;
  if (capModel !== baseModel || baseModel !== cpModel)
    fail(`model identity mismatch: ${capModel} vs ${baseModel} vs ${cpModel}`);
  if (env.model_digest !== "c6eb396dbd59") fail("model digest missing/invalid");

  // sampling equality
  function eq(a, b) {
    return JSON.stringify(a) === JSON.stringify(b);
  }
  if (!eq(capMetrics.sampling, env.sampling))
    fail("capability sampling mismatch");
  if (!eq(baseMetrics.sampling, env.sampling))
    fail("baseline sampling mismatch");
  if (!eq(cpMetrics.sampling, env.sampling))
    fail("code-pact sampling mismatch");

  // output protocol markers present in prompts
  for (const p of [
    "baseline/prompt-initial.txt",
    "baseline/prompt-repair.txt",
    "code-pact/prompt-initial.txt",
  ]) {
    const txt = readFileSync(path.join(root, p), "utf8");
    for (const m of facts.output_protocol.markers) {
      if (!txt.includes(m)) fail(`prompt ${p} missing marker ${m}`);
    }
  }

  // invocation limits
  if (capMetrics.attempts !== 1)
    fail(`capability attempts ${capMetrics.attempts} > 1`);
  const baseAttempts = 1 + (baseMetrics.repair ? 1 : 0);
  if (baseAttempts > 2 || baseMetrics.repairs > 1)
    fail("baseline invocation/repair limit exceeded");
  const cpAttempts = 1 + (cpMetrics.repair ? 1 : 0);
  if (cpAttempts > 2 || cpMetrics.repairs > 1)
    fail("code-pact invocation/repair limit exceeded");

  // token arithmetic
  function checkTokens(cond) {
    const m = JSON.parse(
      readFileSync(path.join(root, `${cond}/metrics.json`), "utf8"),
    );
    let input = 0,
      output = 0;
    for (const k of ["initial", "repair"]) {
      const a = m[k];
      if (!a) continue;
      input += a.input_tokens || 0;
      output += a.output_tokens || 0;
    }
    if (input !== m.total_input)
      fail(`${cond} total_input mismatch: ${input} vs ${m.total_input}`);
    if (output !== m.total_output)
      fail(`${cond} total_output mismatch: ${output} vs ${m.total_output}`);
    if (input + output !== m.total_tokens)
      fail(`${cond} total_tokens mismatch`);
  }
  checkTokens("baseline");
  checkTokens("code-pact");

  // oracle equality: both pass and changed-files equal
  const baseOracle = JSON.parse(
    readFileSync(path.join(root, "baseline/oracle.json"), "utf8"),
  );
  const cpOracle = JSON.parse(
    readFileSync(path.join(root, "code-pact/oracle.json"), "utf8"),
  );
  if (!baseOracle.final_passed) fail("baseline final_passed false");
  if (!cpOracle.final_passed) fail("code-pact final_passed false");

  const baseChanged = JSON.parse(
    readFileSync(path.join(root, "baseline/changed-files.json"), "utf8"),
  );
  const cpChanged = JSON.parse(
    readFileSync(path.join(root, "code-pact/changed-files.json"), "utf8"),
  );
  if (baseChanged.length !== cpChanged.length)
    fail("changed-files count mismatch");
  for (let i = 0; i < baseChanged.length; i++) {
    if (baseChanged[i].path !== cpChanged[i].path)
      fail(
        `changed-file path mismatch ${baseChanged[i].path} vs ${cpChanged[i].path}`,
      );
    if (baseChanged[i].sha256 !== cpChanged[i].sha256)
      fail(`changed-file content mismatch: ${baseChanged[i].path}`);
    if (!baseChanged[i].allowed)
      fail(`baseline file not allowed: ${baseChanged[i].path}`);
    if (!cpChanged[i].allowed)
      fail(`code-pact file not allowed: ${cpChanged[i].path}`);
  }
  if (baseChanged.length !== facts.write_scope.length)
    fail("changed-files count != write_scope");
  const changedPaths = new Set(baseChanged.map(x => x.path));
  for (const w of facts.write_scope) {
    if (!changedPaths.has(w)) fail(`write_scope not modified: ${w}`);
  }

  // code-pact lifecycle ordering
  function getYamlField(file, key) {
    const text = readFileSync(path.join(root, file), "utf8");
    const m = text.match(new RegExp(`^${key}:\\s*(.+)$`, "m"));
    return m ? m[1].trim() : undefined;
  }
  const startAt = getYamlField("code-pact/task-start.yaml", "at");
  const completeAt = getYamlField("code-pact/task-complete.yaml", "at");
  const finalize = JSON.parse(
    readFileSync(path.join(root, "code-pact/task-finalize.json"), "utf8"),
  );
  if (!startAt || !completeAt) fail("missing lifecycle timestamps");
  else if (new Date(startAt) >= new Date(completeAt))
    fail("start not before complete");
  if (!finalize.ok) fail("finalize not ok");

  // review bundle presence
  if (!existsSync(path.join(root, "code-pact/review-bundle.zip")))
    fail("code-pact review-bundle.zip missing");
  const rbStat = statSync(path.join(root, "code-pact/review-bundle.zip"));
  if (rbStat.size === 0) fail("code-pact review-bundle.zip empty");
  const rbAttempt = JSON.parse(
    readFileSync(
      path.join(root, "code-pact/review-bundle-attempt.json"),
      "utf8",
    ),
  );
  if (!rbAttempt.ok)
    warnings.push(
      `task review-bundle command refused: ${rbAttempt.error?.message || rbAttempt.error || "unknown"}`,
    );

  // classification derivation
  const result = {
    pair_status:
      baseOracle.final_passed && cpOracle.final_passed && errors.length === 0
        ? "qualified"
        : "unqualified",
    token_result:
      baseOracle.final_passed && cpOracle.final_passed
        ? cpMetrics.total_tokens < baseMetrics.total_tokens
          ? "code_pact_advantage"
          : "not_comparable"
        : "not_comparable",
    repair_round_result:
      baseOracle.final_passed && cpOracle.final_passed
        ? cpMetrics.repairs < baseMetrics.repairs
          ? "code_pact_advantage"
          : "not_comparable"
        : "not_comparable",
    product_effectiveness:
      baseOracle.final_passed && cpOracle.final_passed
        ? "not_demonstrated_single_pair"
        : "not_demonstrated_single_pair",
  };
  const outDir = path.dirname(path.resolve(zipPath));
  writeFileSync(
    path.join(outDir, "verification-result.json"),
    JSON.stringify(
      {
        schema_version: 1,
        ok: errors.length === 0,
        errors,
        warnings,
        result,
        timestamp: new Date().toISOString(),
      },
      null,
      2,
    ),
  );

  if (errors.length > 0) {
    console.error(`Verification failed: ${errors.length} error(s)`);
    process.exit(1);
  }
  console.log("Verification passed");
  console.log(JSON.stringify({ ok: true, result, warnings }, null, 2));
} finally {
  rmSync(tmp, { recursive: true, force: true });
}
