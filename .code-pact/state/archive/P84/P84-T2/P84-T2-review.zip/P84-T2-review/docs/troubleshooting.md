# Troubleshooting

When a command surfaces one of the diagnostic codes below, this page maps it to the typical recovery action. The full per-code reference is in [`docs/cli-contract.md` § Error codes](cli-contract.md#error-codes); for the project walkthrough these examples are drawn from, see [dogfood.md](dogfood.md). Unfamiliar with a term? See the [glossary](glossary.md).

## Quick lookup

| Code                                                                                                                                                                                                                         | Usually means                                                                                        | Start here                                                                                                                                                                                                                                 |
| ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| [`VERIFICATION_FAILED`](#verification_failed-from-task-complete-or-standalone-verify)                                                                                                                                        | A completion check failed (command **or** decision gate)                                             | On `task complete`: read `error.cause_code`. On standalone `verify` default/full: inspect `data.checks`. With `--detail agent`: inspect `data.failure.kind`, `check`, and `reason` first                                                   |
| [`INVALID_EVIDENCE_REF` / `EVIDENCE_*`](#evidence-retrieval-errors-from-evidence-show-or-agent-detail)                                                                                                                       | A cached verification evidence artifact cannot be retrieved or trusted                               | Re-run the failing verification if the evidence is missing/stale; inspect `data.system_code` or `data.failure.evidence_error` for filesystem/cache faults                                                                                  |
| [`INVALID_CONTEXT_REF` / `CONTEXT_*`](#context-retrieval-errors-from-context-show)                                                                                                                                           | A deferred context artifact cannot be retrieved or trusted                                           | Use the exact `retrieve_command` from `task prepare`; if the cache is missing or corrupt, rerun `task prepare` to recreate the context                                                                                                     |
| [`INVALID_TASK_TRANSITION`](#invalid_task_transition-from-task-start--block--resume--complete)                                                                                                                               | Wrong state transition (e.g. complete a blocked task)                                                | Check `task status`; `task resume` first                                                                                                                                                                                                   |
| [`TASK_FINALIZE_NOT_ELIGIBLE`](#task_finalize_not_eligible-from-task-finalize)                                                                                                                                               | Task isn't `done` yet                                                                                | Run `task complete` first                                                                                                                                                                                                                  |
| [`TASK_FINALIZE_WRITE_REFUSED`](#task_finalize_write_refused-from-task-finalize---write)                                                                                                                                     | Phase-YAML write blocked by the safety check                                                         | Read `data.reason`; usually fix the phase file                                                                                                                                                                                             |
| [`PHASE_RECONCILE_WRITE_REFUSED`](#phase_reconcile_write_refused-from-phase-reconcile---write)                                                                                                                               | Every reconcile write was refused                                                                    | Re-run dry-run; fix the phase file                                                                                                                                                                                                         |
| [`DECISION_PRUNE_NOT_ELIGIBLE`](#decision_prune_not_eligible-from-decision-prune)                                                                                                                                            | A decision record cannot be retired yet                                                              | Read `data.blocks[]`; resolve each gate (or pick a different target)                                                                                                                                                                       |
| [`DECISION_PRUNE_PLAN_STALE`](#decision_prune_plan_stale-from-decision-prune---write)                                                                                                                                        | The tree changed under a `--write` plan (zero writes)                                                | Re-run `decision prune` to rebuild the plan                                                                                                                                                                                                |
| [`DECISION_PRUNE_WRITE_FAILED`](#decision_prune_write_failed-from-decision-prune---write)                                                                                                                                    | A disk write failed during `--write`                                                                 | Read `data.phase` / `data.partial_applied`; fix the cause and re-run                                                                                                                                                                       |
| `PARTIAL_MUTATION` / `TRANSACTION_CLEANUP_PENDING` / `ADAPTER_TRANSACTION_RECOVERY_FAILED`                                                                                                                                   | Adapter staged transaction failed or a pending adapter journal could not be recovered safely         | Inspect `data.journal_path`, `data.backup_paths`, `data.rollback_failures`, and `data.cleanup_failures`. Do not delete journals/backups blindly; cleanup-pending committed journals are normally cleaned by re-running the adapter command |
| [`DELETE_INTENT_RECOVERY_FAILED` / `DELETE_INTENT_DURABILITY_FAILED` / `PENDING_DELETE_INTENT`](#delete_intent_recovery_failed--delete_intent_durability_failed--pending_delete_intent-from-state-archive-retention---write) | A delete-intent journal fault or recovery-authority failure (fail-closed)                            | Read `data.journal_status` / `recovery_failure_kind` / `reason`. `PENDING_*` (and a transient `*_DURABILITY_*`) is re-runnable; `*_RECOVERY_FAILED` is NOT — inspect/repair the journal or the referenced bundles before retry             |
| [`LOCK_HELD`](#lock_held-from-a-lock-covered-mutation)                                                                                                                                                                       | Another mutation is running                                                                          | Wait, then retry (transient)                                                                                                                                                                                                               |
| [`MANIFEST_NOT_FOUND`](#manifest_not_found-from-adapter-upgrade---check----write)                                                                                                                                            | Adapter not installed yet                                                                            | Run `adapter install <agent>`                                                                                                                                                                                                              |
| [`ADAPTER_GENERATOR_STALE`](#adapter_generator_stale-from-adapter-doctor--global-doctor)                                                                                                                                     | Older CLI stamp **and** generated output drifted (stamp-only lag is silent)                          | Run `adapter upgrade --check`, then `--write`                                                                                                                                                                                              |
| [`PLAN_NORMALIZE_REQUIRED`](#plan_normalize_required-from-plan-normalize---check)                                                                                                                                            | Whitespace / newline drift                                                                           | Run `plan normalize --write`                                                                                                                                                                                                               |
| [`CONFIG_ERROR` (reserved `TUTORIAL`)](#config_error-from-phase-add---id-tutorial--phase-import-containing-tutorial)                                                                                                         | Tried to create a `TUTORIAL` phase                                                                   | Pick a different phase id                                                                                                                                                                                                                  |
| [`DECISION_REQUIRED`](#decision_required-from-task-record-done)                                                                                                                                                              | A `requires_decision` task has no **accepted** ADR                                                   | Flip the ADR's `**Status:**` to `accepted`                                                                                                                                                                                                 |
| [`ADR_STATUS_UNRECOGNIZED`](#adr_status_unrecognized-from-plan-lint---include-quality)                                                                                                                                       | An ADR's status word is a typo                                                                       | Fix the `**Status:**` line named in `details.status_source`                                                                                                                                                                                |
| [`CONTROL_PLANE_NOT_DRIVEN`](#control_plane_not_driven-from-doctor)                                                                                                                                                          | Scaffold adopted but the loop isn't being driven                                                     | Start a task, or silence the check                                                                                                                                                                                                         |
| [`CONTROL_PLANE_BRANCH_NOT_DRIVEN`](#control_plane_branch_not_driven-from-doctor--validate---base-ref)                                                                                                                       | A PR branch changed real code but never drove the loop                                               | Drive a task (or `record-done`) and commit the ledger (`state/events/**`), or exempt the path                                                                                                                                              |
| [`ADR_ACCEPTED_BODY_THIN`](#adr_accepted_body_thin-from-plan-lint---include-quality)                                                                                                                                         | An accepted ADR's body is an empty stub                                                              | Add the decision + rationale, or revert status to `proposed`                                                                                                                                                                               |
| [`ADR_COMMITMENTS_EMPTY`](#adr_commitments_empty-from-plan-lint---include-quality)                                                                                                                                           | An accepted ADR that resolves a gated task's gate records no implementation commitments              | Add a `## Implementation commitments` checkbox list (warning only — never blocks)                                                                                                                                                          |
| [`PHASE_DOCS_WRITE_NO_DOC_CHECK`](#phase_docs_write_no_doc_check-from-plan-lint---include-quality)                                                                                                                           | A not-done phase writes public docs but runs no doc check                                            | Add `pnpm check:docs` to the phase's verification.commands (warning only)                                                                                                                                                                  |
| [`TASK_CONTEXT_PACK_LARGE`](#context-fit-advisories-from-plan-lint---include-quality)                                                                                                                                        | Natural context pack > balanced budget (60000 bytes)                                                 | Consider a wider profile or review task scope (advisory only)                                                                                                                                                                              |
| [`TASK_CONTEXT_BUDGET_UNACHIEVABLE`](#context-fit-advisories-from-plan-lint---include-quality)                                                                                                                               | Recommended budget below the achievable floor                                                        | Use a wider profile or split the task (advisory only)                                                                                                                                                                                      |
| [`TASK_DECLARED_DECISION_LARGE`](#context-fit-advisories-from-plan-lint---include-quality)                                                                                                                                   | A `decision_refs` body > tight budget (30000 bytes)                                                  | Split follow-up tasks or confirm scope (advisory only)                                                                                                                                                                                     |
| [`TASK_READS_MATCH_TOO_MANY`](#context-fit-advisories-from-plan-lint---include-quality)                                                                                                                                      | A `reads` glob matches > 100 files                                                                   | Narrow the glob if the task can be scoped (advisory only)                                                                                                                                                                                  |
| [`TASK_READS_NO_MATCH`](#task_reads_no_match-from-plan-lint)                                                                                                                                                                 | A task `reads` glob matches no live file (often after renaming/merging a referenced source file)     | If the file moved, `plan sync-paths --rename "<old>=<new>" --write`; if it's gone, drop the entry                                                                                                                                          |
| [`EVENT_FILE_ID_MISMATCH`](#event_file_id_mismatch-from-doctor--plan-lint)                                                                                                                                                   | A per-event ledger file's content doesn't match its content-addressed name (corrupt / hand-edited)   | Restore from git or remove the file named in the message, then re-run                                                                                                                                                                      |
| [`PROGRESS_EVENT_CONFLICT`](#progress_event_conflict-from-doctor--plan-analyze)                                                                                                                                              | Incompatible same-task lifecycle events (e.g. two branches both `done` a task)                       | Reconcile the conflicting event(s) for the named task                                                                                                                                                                                      |
| [`CONTROL_PLANE_GITIGNORED`](#control_plane_gitignored-from-doctor)                                                                                                                                                          | A `.gitignore` rule keeps part of the shared control plane off git, so collaboration silently breaks | Narrow the `.gitignore` to the local-only subset and commit the shared control plane (project.yaml, profiles, baselines, state/events/)                                                                                                    |
| [`LOOP_MEMORY_*`](#loop_memory_-from-doctor)                                                                                                                                                                                 | Local bounded loop-memory cache is tracked, not ignored, or path-unsafe                              | Keep `/.code-pact/cache/` ignored, remove local cache files from version control, and replace unsafe cache symlinks with normal project-local directories                                                                                  |
| [`DUPLICATE_PHASE_ID`](#duplicate_phase_id-from-plan-lint--doctor)                                                                                                                                                           | Two phase files claim the same `P<N>` id (often a clean-but-wrong branch merge)                      | Renumber one phase + its roadmap entry, then re-run `plan lint`                                                                                                                                                                            |
| [`DUPLICATE_TASK_ID`](#duplicate_task_id-from-plan-lint--doctor)                                                                                                                                                             | One task id appears in two phases                                                                    | Renumber one task (+ refs to it), then re-run `plan lint`                                                                                                                                                                                  |
| [`PHASE_ID_MISMATCH`](#phase_id_mismatch-from-plan-lint--doctor)                                                                                                                                                             | A phase file's inner `id:` differs from its roadmap entry                                            | Make the two ids match, then re-run `plan lint`                                                                                                                                                                                            |
| [`AMBIGUOUS_PHASE_ID`](#ambiguous_phase_id-and-ambiguous_task_id-fail-closed-id-resolution)                                                                                                                                  | A command resolved a phase id that two files claim — fails closed (exit 2)                           | Resolve the duplicate (see `data.phases`), then retry                                                                                                                                                                                      |
| [`AMBIGUOUS_TASK_ID`](#ambiguous_phase_id-and-ambiguous_task_id-fail-closed-id-resolution)                                                                                                                                   | A command resolved a task id that two phases claim — fails closed (exit 2)                           | Resolve the duplicate (see `data.phases`), then retry                                                                                                                                                                                      |

## `MANIFEST_NOT_FOUND` from `adapter upgrade --check` / `--write`

You haven't run `adapter install <agent>` yet, or the per-agent manifest at `.code-pact/adapters/<agent>.manifest.yaml` was deleted.

```sh
code-pact adapter install <agent>
# then re-run the upgrade.
```

Distinct from the `ADAPTER_MANIFEST_MISSING` _warning_ surfaced by `adapter doctor` for the same root cause — `adapter doctor` is read-only and never fails on a missing manifest; the upgrade commands need a manifest to do their job.

## `INVALID_TASK_TRANSITION` from `task start` / `block` / `resume` / `complete`

The current state derived from the progress ledger doesn't allow the requested transition. The most common case is `task complete` against a `blocked` task — the task must be `resume`d first so the `resumed` event records the unblock decision.

```sh
code-pact task status <task-id> --json
# Read data.current; see docs/cli-contract.md § task * for the
# allowed-transitions table.

code-pact task resume <task-id>   # if currently blocked
code-pact task complete <task-id>
```

## `PLAN_NORMALIZE_REQUIRED` from `plan normalize --check`

A file under `design/` or the legacy `.code-pact/state/progress.yaml` has trailing whitespace, CRLF line endings, or a missing/extra final newline. (Per-event files under `.code-pact/state/events/` are machine-generated and not normalized.)

```sh
code-pact plan normalize --write
# Idempotent. Comments and Markdown hard line breaks are preserved.
```

`plan normalize --write` is the apply-mode counterpart to `--check`. Passing both at once is a `PLAN_NORMALIZE_CONFLICT` (exit 2) so the intent is unambiguous in CI scripts.

## `TASK_READS_NO_MATCH` from `plan lint`

A task's `reads` glob matches no file on disk. `plan lint --include-quality --strict` (a CI gate) promotes this warning to a failure. It fires after you rename, merge, or delete a source file that a phase — often a **done, historical** one — still lists in its `reads` (or `writes`): the phase's recorded file surface and the live tree have diverged.

If the file **moved or was merged**, redirect the stale entries with an explicit old=new rename map. Repeat `--rename` per move; entries that collapse to the same path are de-duplicated. Dry-run first, then apply:

```sh
code-pact plan sync-paths --rename src/old.ts=src/new.ts --json          # preview (writes nothing)
code-pact plan sync-paths --rename src/old.ts=src/new.ts --write --json  # apply
code-pact plan lint --include-quality --strict --json                    # confirm green
```

The map is explicit by design: a moved file can be a rename, a merge, or a split, none of which is recoverable from git heuristics, so you state the intent. `plan sync-paths` only rewrites `reads` / `writes` of tasks under `design/phases/`; it never touches CHANGELOG or RFC prose. If the file is **gone for good**, remove the entry from the phase YAML by hand.

## `VERIFICATION_FAILED` from `task complete` (or standalone `verify`)

A deterministic completion check did not pass. `task complete` runs two checks — `commands` (the phase's `verification.commands`) and `decision` (the `requires_decision` ADR gate) — so `VERIFICATION_FAILED` is **not** only a command failure.

**For `task complete`, read `error.cause_code` first — you usually don't need to re-run `verify`.** In default/full detail, the `task complete` `VERIFICATION_FAILED` envelope carries an additive `error.cause_code` and a detailed `error.message`:

- `error.cause_code: "COMMANDS_FAILED"` → a verification command failed. `error.message` embeds the failing command's reason. Fix the command (or, if the command itself is wrong — typo, missing dependency — edit `design/phases/<phase>.yaml` `verification.commands`), then re-run.
- `error.cause_code: "DECISION_REQUIRED"` → the task `requires_decision` and no **accepted** ADR resolves the gate. `error.message` says an accepted ADR is required. Write/accept the ADR (see [`DECISION_REQUIRED` from `task record-done`](#decision_required-from-task-record-done) for the gate semantics), then re-run. `error.code` stays `VERIFICATION_FAILED` at exit 1 (the full structured `DecisionRequiredData` block only appears on `task record-done`).
- `error.cause_code: "ABORTED"` → the caller, `SIGINT`, or `SIGTERM` cancelled verification. Code Pact terminates the active process tree and does not record a `task complete` event before the atomic event-write commit point. Clear the cancellation source, then re-run. Programmatic signal delivery is platform-dependent; on Windows, prefer timeout or caller-driven `AbortSignal` cancellation for deterministic automation tests.

```sh
code-pact verify --phase <phase-id> --task <task-id> --timeout 300000
# --timeout is per command, in decimal milliseconds; valid range: 1..2147483647.
# Runs the same checks stand-alone so you can read default/full data.checks.
# No progress event is recorded when verify fails; re-run task complete
# after fixing the underlying issue.
```

**Default/full `data` detail.** The default/full `task complete` failure envelope carries `failed_checks`, `first_failure: { name, reason }`, and `suggested_next_command` under `data`, alongside `data.verify.checks`. Standalone `verify` default/full keeps the detailed message and per-check results under `data.checks`; ordinary command/decision failures there do not guarantee `error.cause_code` (cancellation reports `ABORTED`). The same three summary fields also appear on the `task finalize` failure envelopes (`TASK_FINALIZE_NOT_ELIGIBLE`, `TASK_FINALIZE_WRITE_REFUSED`, `WRITES_AUDIT_STRICT_FAILED`) — but `finalize` does **not** run verify, so there is no `data.verify.checks` there; the summary sits alongside the finalize-specific `data` instead (e.g. `data.write_audit` on `WRITES_AUDIT_STRICT_FAILED`, `data.current` / `data.phase_id` on `TASK_FINALIZE_NOT_ELIGIBLE`). Human (non-`--json`) output leads with the actionable cause headline (the `cause_code` message above — no longer a generic line) and prints `cause:` and `rerun after fixing:` lines below it. `suggested_next_command` is the command to rerun **after fixing** `first_failure` — not a hint that re-running unchanged will pass.

### Agent detail mode

With `--json --detail agent`, `error.message` is intentionally short; do not treat it as the actionable detail. Diagnose in this order: `data.failure.kind`, `data.failure.check`, `data.failure.reason`, `data.failure.fingerprint` when present, `data.failure.stderr_excerpt` when present, `data.failure.stdout_excerpt` when present, `data.failure.evidence_error` when present, then `data.failure.retrieve_command` only if needed.

`fingerprint`, stdout/stderr excerpts, `evidence_ref`, and `retrieve_command` are optional and normally appear only for command-output failures. Their absence on `decision_required`, `invalid_state`, preflight, or configuration failures is expected. Use the bounded excerpts first; retrieve full Evidence only for command-output failures when the excerpts are insufficient to decide the fix.

## Evidence retrieval errors from `evidence show` or agent detail

`verify --json --detail agent` and `task complete --json --detail agent` may return an `evidence_ref` plus a `retrieve_command` such as `code-pact evidence show evidence:sha256:<digest> --json`. Evidence is a derived, gitignored cache of bounded command output. It is useful for debugging a verification failure, but it is not the durable proof of task completion.

For top-level `evidence show` failures:

| Code                       | Recovery                                                                                                                                                                          |
| -------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `INVALID_EVIDENCE_REF`     | The ref is malformed. Use the exact `data.failure.retrieve_command` emitted by the failing verification run.                                                                      |
| `EVIDENCE_NOT_FOUND`       | The cache entry is absent, usually because the workspace was cleaned or the ref came from another checkout. Re-run the failing verification command to recreate current evidence. |
| `EVIDENCE_INVALID`         | The cache file is corrupt or schema-invalid. Delete the derived cache entry only if you are sure it is local generated state, then re-run the failing verification.               |
| `EVIDENCE_DIGEST_MISMATCH` | The cache file's bytes do not match the digest in the ref. Treat the cache as untrusted and re-run verification instead of reading the artifact.                                  |
| `EVIDENCE_PATH_UNSAFE`     | Evidence path resolution crossed a traversal, symlink, or authority boundary. Inspect `.code-pact/cache/evidence/` and remove the unsafe cache shape before retrying.             |
| `EVIDENCE_READ_FAILED`     | The cache could not be read for an I/O/platform reason. Inspect `data.system_code` for the underlying errno, fix permissions or filesystem state, then retry.                     |

For nested agent-detail cache failures, the top-level error remains `VERIFICATION_FAILED`; read `data.failure.evidence_error`. `code: "EVIDENCE_UNAVAILABLE"` means verification still failed, but Code Pact could not store the optional evidence artifact. `cause_code` distinguishes `EVIDENCE_CONFLICT`, `EVIDENCE_PATH_UNSAFE`, and `EVIDENCE_WRITE_FAILED`. Fix the cache/filesystem issue if you need retrieval, otherwise use the bounded stdout/stderr excerpts in `data.failure` to diagnose the original verification failure.

## Context retrieval errors from `context show`

Budgeted `task prepare` may return a `deferred_context.manifest_ref` and `retrieve_command`. The cache is derived and content-addressed; it is safe to recreate by rerunning the same prepare command when inputs have not changed.

Do not hand-edit or commit `.code-pact/cache/context/`. Use `context show <ref> --list --json` to inspect available sections, then retrieve only the needed section with `--section <name>`.

| Code                      | Recovery                                                                                                                                                                                         |
| ------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| `INVALID_CONTEXT_REF`     | The ref is malformed. Use the exact `retrieve_command` emitted by `task prepare`.                                                                                                                |
| `CONTEXT_NOT_FOUND`       | The cache entry is absent, usually because local derived state was cleaned or a competing cache mutation removed it before readback. Rerun `task prepare` with the same budget to recreate it.   |
| `CONTEXT_INVALID`         | The artifact is corrupt, schema-invalid, not canonical, or has mismatched section metadata. Treat it as untrusted and rerun `task prepare`.                                                      |
| `CONTEXT_DIGEST_MISMATCH` | The artifact bytes or section body no longer match the recorded digest. Treat the cache as untrusted and rerun `task prepare`.                                                                   |
| `CONTEXT_PATH_UNSAFE`     | Context path resolution crossed a traversal, symlink, or authority boundary. Inspect `.code-pact/cache/context/` and remove the unsafe cache shape before retrying.                              |
| `CONTEXT_READ_FAILED`     | The cache could not be read for an I/O/platform reason. Inspect `data.system_code`, fix permissions or filesystem state, then retry.                                                             |
| `CONTEXT_WRITE_FAILED`    | The cache could not be written for an I/O/platform reason. Inspect `data.system_code`, fix permissions or disk state, then rerun `task prepare`. No context pack is written before this failure. |

## `TASK_FINALIZE_NOT_ELIGIBLE` from `task finalize`

The task's derived state from the progress ledger is not `done`, so flipping its design YAML status would create a worse drift (design says done, progress says otherwise). The check fires in **both** dry-run and `--write` — dry-run means "won't write", not "won't validate".

```sh
code-pact task status <task-id> --json
# Read data.current. Common cases:
#   - current: "planned" → you forgot to run `task complete` (or
#     `task start` + implementation + `task complete`).
#   - current: "blocked" → resume first, then complete, then finalize.
#   - current: "started" / "resumed" → still in progress; complete
#     the task first.
#   - current: "failed" → the verify failed at task complete; fix
#     the underlying issue, complete again, then finalize.

# Alternative: `task runbook` returns the same diagnosis plus
# the recommended next step inline (no manual state interpretation).
code-pact task runbook <task-id> --json
# Read data.state_summary + data.next_steps[0].command.
```

`task finalize` deliberately refuses ineligible cases instead of guessing. Every legitimate path through the state machine ends in a `done` event, which is the precondition for finalization.

## `TASK_FINALIZE_WRITE_REFUSED` from `task finalize --write`

The phase YAML write was refused by the safety classifier. `data.reason` is one of:

| Reason                  | Cause                                                                   | Recovery                                                                                                |
| ----------------------- | ----------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------- |
| `unsafe_path`           | The resolved path failed `assertSafeRelativePath` (traversal, absolute) | Should not happen from normal CLI use; report a bug                                                     |
| `outside_design_phases` | The phase file resolves outside `design/phases/`                        | Same — should not happen via the roadmap-driven resolver                                                |
| `not_yaml`              | The phase file does not end in `.yaml`                                  | Rename the phase file to `.yaml`                                                                        |
| `symlink_escape`        | `resolveWithinProject` detected a symlink leaving the project root      | Replace the symlink with the actual file inside the project                                             |
| `unreadable`            | The phase file could not be read (permissions, missing)                 | `ls -l design/phases/` and fix file permissions or restore the file                                     |
| `unparseable_phase`     | The phase file's YAML failed schema parse                               | Run `code-pact plan lint --json` — the underlying parse error is reported there                         |
| `task_not_found`        | The task id is not in the phase's `tasks[]` array                       | The task id and phase do not match; verify the task id against `code-pact phase show <phase-id> --json` |

`task finalize --write` will not partially-modify a phase file. If the safety check fails, no write occurs.

## `PHASE_RECONCILE_WRITE_REFUSED` from `phase reconcile --write`

Every eligible task write was refused for safety reasons. Partial successes (one or more applied + one or more refused) return exit 0 — this code only fires when the whole batch failed. `data.skipped_writes[]` carries per-task refusal detail in the same `reason` enum as `TASK_FINALIZE_WRITE_REFUSED` above.

```sh
code-pact phase reconcile <phase-id> --json
# Re-run in dry-run mode to inspect the per-task verdicts. Fix the
# underlying cause (unparseable phase file is the most common) and
# re-run with --write.

# Alternative: `phase runbook` returns the same per-task verdicts
# plus the recommended next steps (blocked / manual_review / reconcile
# batch / primary loop / phase-status advisory).
code-pact phase runbook <phase-id> --json
```

If `data.tasks[]` shows every flip candidate has the same refusal reason, the issue is the phase file itself, not individual tasks — fix it once and reconcile will proceed for all of them.

## `DECISION_PRUNE_NOT_ELIGIBLE` from `decision prune`

The target decision record cannot be retired. The verdict is identical for the dry-run preview and `--write`, so an ineligible target is **never** written either way — nothing is deleted. `data.blocks[]` lists **every applicable** failing gate so you can resolve them together (the link-rewrite gates below are only evaluated once the target itself is a readable, accepted decision record — a `target_*` failure short-circuits them):

```sh
code-pact decision prune design/decisions/<path>.md --json
# data.blocks[].gate is one of:
#   target_invalid / target_missing / target_unreadable
#     → the target is not a readable .md decision record under design/decisions/
#   plan_artifacts_unreadable
#     → design/roadmap.yaml or a referenced design/phases/*.yaml could not be read,
#       so prune cannot prove every referencing task is done; fix the plan graph first
#   link_rewrite_unsupported
#     → a doc links to the decision with a reference-style link ([t][label] + [label]: …)
#       — convert it to an inline link [t](…); OR a markdown link to the decision sits
#       inside the append-only PRUNED.md ledger — remove that link by hand (the ledger
#       is never rewritten)
#   link_rewrite_scan_unreadable
#     → a doc source under the scanned surface could not be read, so the rewrite
#       plan would be incomplete; fix/remove the unreadable file
#   target_not_accepted
#     → only an accepted decision is prunable; a proposed/draft/rejected/
#       superseded/empty/unknown one is not (data.blocks[].status names it)
#   referencing_task_not_done
#     → a not-`done` task still references it (finish or re-scope that task)
#   open_commitments
#     → check off (or remove) the `## Implementation commitments` items
#   live_decision_depends / dependency_status_unknown
#     → a proposed/draft (or typo'd-status) decision links to it; settle that
#       decision first, or fix its status line
#   decision_scan_unreadable / dependency_unreadable
#     → a file under design/decisions/ could not be read (e.g. a directory
#       named *.md); fix the tree so the scan can complete
```

When `data.eligible` is `true` but `data.referencing_tasks` is empty, prune cannot prove the decision was shipped through a task reference — confirm it is genuinely retired, not an unconnected record, before relying on it.

## `DECISION_PRUNE_PLAN_STALE` from `decision prune --write`

The working tree changed between building the plan and applying it (a concurrent edit to a doc, or a plan applied against a tree that has since moved). `--write` re-collects inbound links and requires the plan to still describe the tree exactly, then re-checks every span byte-for-byte — so this aborts with **zero writes**: the record is not deleted, no link is rewritten, no ledger row is appended.

```sh
code-pact decision prune design/decisions/<path>.md --write --json
# data → { mode: "write", decision, stale[] }
# each stale[] entry describes one divergence:
#   { source_file, line, column, expected, found }
#   expected → the raw_link the plan recorded (or a marker for a new/unsupported link)
#   found    → what is on disk there now (or a marker: <reclassified>, <reference-style>, …)
```

Recovery: re-run `decision prune` (dry-run first if you want to inspect the rebuilt plan). The collector re-reads the current tree, so a fresh `--write` reflects the edit. This is a safety abort, not a failure — nothing was left half-applied. The **target record** disappearing, becoming a directory, or being **edited in place** (same inode, different bytes — e.g. status flipped back to `proposed`) between the verdict and apply is the same kind of drift and also lands here — the record is never deleted on a verdict that no longer holds.

## `DECISION_PRUNE_WRITE_FAILED` from `decision prune --write`

A write could not complete **after** preflight passed — distinct from `PLAN_STALE` (a plan/tree mismatch caught **before** any write). Causes:

- an unreadable ledger, or **`PRUNED.md` edited since preflight** — refused so your ledger edit is never clobbered (`phase: append_ledger`, zero writes);
- a **source edited since preflight** — the rewrite is refused so your edit is never clobbered (`phase: rewrite_links`);
- the **record disappearing** before the delete step — code-pact did not remove it, so it says so instead of claiming a removal (`phase: delete_record`);
- a commit-time `rename`/`unlink` I/O error (disk full, permissions, a path that became a directory).

```sh
code-pact decision prune design/decisions/<path>.md --write --json
# data → { mode: "write", decision, phase, partial_applied, message }
#   phase           → append_ledger | rewrite_links | delete_record
#   partial_applied → false = nothing landed; true = some changes already applied
#   message         → e.g. "source changed after preflight: docs/x.md",
#                     "target disappeared before unlink", ENOSPC, EACCES, EISDIR
```

`partial_applied` reports whether **this invocation** already changed the tree: the ledger was appended **this run** (not an idempotent already-recorded retry), or ≥1 source was rewritten. `append_ledger` is therefore always `false`; `rewrite_links` / `delete_record` are `true` **except** on an already-recorded retry that fails before any rewrite lands (then `false` — nothing was mutated this run, so there is nothing to inspect). When `partial_applied` is `true`, inspect the working tree (`git status` / `git diff`) before retrying — the ledger row and/or some link rewrites are already committed; a re-run is **idempotent** (a decision already in `PRUNED.md` is not re-appended). A `rewrite_links` failure from a concurrent edit means your edit is intact — re-run `decision prune` to rebuild the plan against it.

## `DELETE_INTENT_RECOVERY_FAILED` / `DELETE_INTENT_DURABILITY_FAILED` / `PENDING_DELETE_INTENT` from `state archive-retention --write`

These are the fail-closed faults of the **delete-intent journal** — how the archive removes a `phase_snapshot` ↔ `event_pack` pair both-or-neither across a crash. They surface from `state archive-retention --write` AND `state archive-maintain --write` (both recover the journal first), and from `state compact-archive --write` (which is NOT recovery-first, so it REFUSES while a journal is pending — see the `state compact-archive` note below). **A valid `present` journal is NORMALLY recoverable** — a re-run of a recovery-first command (`state archive-maintain --write`) completes it. But recovery itself can still FAIL (`DELETE_INTENT_RECOVERY_FAILED`); when it does, a blind re-run fails the same way and you must inspect/repair — see the next bullet for which thing to repair.

- **`DELETE_INTENT_RECOVERY_FAILED`** — recovery could not use its authority safely. Read `data.recovery_failure_kind` (and `data.journal_status`): **`journal_corrupt`** (`journal_status: "corrupt"`) — the journal file itself is unreadable / non-canonical; inspect/repair (or intentionally remove, after verifying the archive state) `.code-pact/state/archive/delete-intent.json`. **`present_journal_recovery_failed`** (`journal_status: "present"`) — the journal is VALID, but the archive bundles/files it references are missing or their bytes changed since the commit; inspect/repair the **referenced archive bundles**, not the journal. In both cases NO new plan proceeds and a blind re-run fails the same way — but "fail-closed" does NOT mean "nothing was deleted": a valid `present` journal's recovery may already have completed PART of the committed prior delete before failing (a mixed journal's loose unlinks run before its bundle retires), so read `data.partial_applied` and inspect the remaining journal / referenced authority before retrying.
- **`DELETE_INTENT_DURABILITY_FAILED`** — a REQUIRED durability barrier (`fsync` of the journal's temp data, or of a directory) failed with a real I/O fault (`reason: "failed"`). A platform that simply cannot `fsync` a directory (`reason: "unsupported"`, e.g. Windows) is NOT this error — it defers the pair conservatively (`requires_atomic_pair_removal`) instead. Fix the I/O fault and re-run.
- **`PENDING_DELETE_INTENT`** — a journal already exists when a new pair-delete tried to start (a prior crash was not recovered). The apply recovers first, so this is a defensive guard; re-run and recovery completes the prior journal before the new plan.

```json
{
  "ok": false,
  "error": {
    "code": "DELETE_INTENT_DURABILITY_FAILED",
    "message": "directory fsync failed (commit, ...): EIO"
  },
  "data": {
    "recovery_pending": true,
    "journal_status": "present",
    "partial_applied": true,
    "reason": "failed"
  }
}
```

Read `data.journal_status` (`absent` / `present` / `corrupt`), `data.reason` (`failed` = a real I/O fault, fix it and re-run; `unsupported` = the platform cannot `fsync` a directory, so the pair was deferred conservatively — not this error), and `data.partial_applied` (a valid `present` journal's recovery may have completed part of a committed delete before failing). `data.recovery_pending` says whether a journal still remains: `true` → for a re-runnable fault, a re-run completes it (both-or-neither); the deletion is always atomic across these failures — you never get one half of a pair.

## Reading `state archive-maintain --write` output

`state archive-maintain --write` orchestrates the low-level archive verbs (recover → `compact-archive` → `archive-retention` → compact again → re-plan → `validate` → `plan lint`). It adds no new destructive semantics, so its faults are the SAME codes the low-level verbs surface, plus an honest `bounded_status`. Common operator questions:

- **A maintenance step failed (exit 2).** The error envelope carries the underlying code (`ARCHIVE_BUNDLE_WRITE_FAILED` / `ARCHIVE_BUNDLE_INVALID` / a `DELETE_INTENT_*` / `PENDING_DELETE_INTENT` / `BUNDLE_PAIR_NOT_COMMITTABLE`) plus `data.step` (which step), `data.completed_steps` (what already ran), `data.partial_applied`, and — when the run had already completed a journal recovery before the fault — `data.recovered` (so a recovery-completed drop is never lost on the error path). Treat it exactly as you would the same code from `state compact-archive` / `state archive-retention` (see the `DELETE_INTENT_*` section above and the `ARCHIVE_BUNDLE_*` / `BUNDLE_PAIR_NOT_COMMITTABLE` rows in [cli-contract.md](cli-contract.md)). A `DELETE_INTENT_DURABILITY_FAILED` with `reason: "unsupported"` is NOT an error path — that platform (e.g. Windows) cannot `fsync` a directory, so the pair is deferred conservatively; the run still succeeds.

- **`PENDING_DELETE_INTENT` from `state compact-archive --write` (NOT from `archive-maintain`).** The low-level `state compact-archive --write` REFUSES when a delete-intent journal is pending — it has no recovery path, and its consolidation would retire a crashed bundle-pair removal's reduced survivor bundle (wedging recovery forever). This is intentional. Run `state archive-maintain --write` instead: it recovers the journal FIRST, then compacts. Never delete the journal by hand to "unblock" compaction — that is the truth that recovery needs.

- **A post-check failed (exit 1, but the envelope is `ok: true`).** The archive MUTATIONS succeeded; the read-only post-checks (`validate` + `plan lint --include-quality --strict`) found a problem. Read `data.steps.checks` for the detail. The exit-1 is a CI convenience signal — the authoritative gates are the separate `validate` / `plan lint` runs. Fix the reported check (usually unrelated to the archive) and re-run, or run the gates directly.

- **The result reports `skipped` records.** A non-empty `summary.skipped` is fail-closed truth that could NOT be removed — never a silent drop. It is the TOTAL of `compact_skipped` + `retention_skipped`, so inspect BOTH — `data.steps.compact_before_retention.skipped[]` and `data.steps.compact_after_retention.skipped[]` (compaction skips) AND `data.steps.retention.results[].skipped[]` (retention skips) — for the per-record reason:
  - `needs_bundle_member_removal` (counted as `summary.bundle_member_deferred`) — a bundle-backed `would_drop` record whose removal the bundle-member layer held back. This is **NOT necessarily a mixed-source pair**: it also covers an independent bundle record, a bundle-backed pack-less phase, a `not_member`, or an unsafe member. The common mixed-source-pair case should already be gone (`archive-maintain`'s compact-first step makes mixed pairs uniform); if it persists, a record is genuinely stuck (e.g. a `bundle_stale` divergent copy) — run `state compact-archive --json` and inspect `would_skip` for the offending id.
  - `requires_atomic_pair_removal` (counted as `summary.atomic_pair_deferred`) — a loose `phase_snapshot` ↔ `event_pack` pair could not be removed through the durable pair-delete path (a missing digest, a partial store view, or an unsupported-platform `fsync`). The pair is retained whole; re-run after resolving the cause (or accept the conservative defer on Windows). `summary.mixed_source_deferred` is the SUM of these two, kept as a compatibility aggregate — act on the two precise counts.
  - `bundle_stale` (from a `state compact-archive` skip) — a loose record DIVERGES from its bundle member and is not adoptable this run. Inspect both copies; the consolidation converges the store over runs, or reconcile the divergence by hand.

- **`bounded_status` says NOT bounded.** This is honest, not a bug — and there are TWO next actions, not one. If `summary.skipped == 0` (and `bundle_member_deferred` / `atomic_pair_deferred` are 0), it is a healthy follow-up (a `source: both` survivor / a recovered bundle-pair survivor) that **converges by re-running** `archive-maintain --write`. If `summary.skipped > 0` (a `bundle_stale` skip, an unsupported-platform `fsync`, a partial store, a missing digest, or a `corrupt`/unrecoverable recovery authority), a blind re-run will NOT converge — **inspect** the per-record reasons first (`data.steps.compact_*.skipped[]`, `data.steps.retention.results[].skipped[]`, the `bounded_status` reason counts). `bundle_byte_size_bounded` is **ALWAYS `false`** — see below.

- **The bundle keeps growing in BYTES even though the file count is bounded.** Expected. `archive-maintain` bounds the archive FILE COUNT (folds the loose tail into ~one bundle per kind) and removes UNREFERENCED old truth. It does NOT bound a single bundle's BYTE SIZE — a kind's bundle grows with the number of REFERENCED records, which are kept by design. Sharding a large bundle (and a referenced-truth lifetime policy) is deferred future work, reported as `bundle_byte_size_bound_deferred_to: "sharding"`. Do not read `bundle_byte_size_bounded: false` as a failure — it is the explicit, intentional boundary of the current archive-maintenance layer.

## `LOCK_HELD` from a lock-covered mutation

Another `code-pact` mutation is in progress on the same project. The advisory write lock (`.code-pact/locks/write.lock`) is held by the process whose details appear in the envelope:

```json
{
  "ok": false,
  "error": {
    "code": "LOCK_HELD",
    "message": "Another code-pact mutation is in progress: phase reconcile P3 --write (pid: 12345, host: laptop.local, started: 2026-05-21T10:15:00.000Z). ..."
  },
  "data": {
    "lock_holder": {
      "pid": 12345,
      "hostname": "laptop.local",
      "cmd": "phase reconcile P3 --write",
      "created_at": "2026-05-21T10:15:00.000Z"
    },
    "lock_path": "/path/to/.code-pact/locks/write.lock"
  }
}
```

**Normal case — another command is running.** Wait for the holder to release (the lock is created/released within a single CLI invocation) and re-run. The lock is transient by design; LOCK_HELD belongs in the retry-on-transient list for any orchestration that runs multiple `code-pact` commands in parallel.

**Stale-lock case — the holder is gone.** A prior `code-pact` process crashed (SIGKILL, OOM, OS reboot) without releasing the lock. code-pact does NOT auto-detect this; recovery is manual and intentionally conservative:

1. Verify no `code-pact` process is running (check `ps` / `pgrep` for the `pid` in `data.lock_holder.pid`; on a different host, check `data.lock_holder.hostname` matches yours).
2. **Only when certain no process holds it**, delete the lock file: `rm .code-pact/locks/write.lock`.
3. Re-run the command.

Do not blindly delete the lock file just because LOCK_HELD fired — if a concurrent mutation IS in progress, deleting the lock undermines the guarantee. The conservative manual-recovery default deliberately favours wait-and-retry over automation, because automated stale detection is subtle (two processes can both decide the other is stale and clobber a real lock).

Read-only commands (`status`, `plan lint`, `plan analyze`, `task runbook`, `phase runbook`, `validate`, `doctor`, `recommend`, `task context`, `task status`) do NOT acquire the lock and can be used to observe project state while a mutation is pending.

See [`docs/concepts/governance.md`](concepts/governance.md) for the governance walkthrough and [`docs/cli-contract.md` § Advisory write lock](cli-contract.md#advisory-write-lock-v15--p14) for the full acquisition-point matrix.

## `CONFIG_ERROR` from `phase add --id TUTORIAL` / `phase import` containing `TUTORIAL`

The id `TUTORIAL` is reserved at the governance layer for the sample-phase artifact created by `code-pact init --sample-phase`. The block fires at creation time on every path except the sanctioned bootstrap.

```sh
# Rejected: phase add cannot create a TUTORIAL phase.
code-pact phase add --id TUTORIAL --name ... --weight 1 --objective ...
# → CONFIG_ERROR (exit 2). Roadmap is byte-identical (no write).

# Rejected: phase import containing a TUTORIAL entry (anywhere in the
# file) is preflighted before any createPhase call, so the whole
# import is rejected with the roadmap untouched.
code-pact phase import path/to/import.yaml
# → CONFIG_ERROR (exit 2) if any phase entry has id: TUTORIAL.

# Sanctioned: init --sample-phase is the only allowed creation path.
code-pact init --sample-phase
# → creates design/phases/TUTORIAL-walkthrough.yaml + the roadmap entry.
```

If you genuinely want a phase named `TUTORIAL` for a non-tutorial purpose, **pick a different id**. The block uses the existing `CONFIG_ERROR` envelope — no new error code ships for this. The error message names the reserved id and points back at `init --sample-phase` as the sanctioned path. Existing projects with a TUTORIAL phase are untouched; the block only fires on new creation. See [`docs/concepts/sample-phase.md`](concepts/sample-phase.md#tutorial-is-a-reserved-phase-id) for the user-facing rules.

## `ADAPTER_GENERATOR_STALE` from `adapter doctor` / global `doctor`

Your adapter manifest's `generator_version` field doesn't match the installed code-pact version **and** the generated adapter output the current CLI would produce no longer matches the manifest.

A stale `generator_version` on its own is **silent**: a no-op patch bump that changes nothing about your generated adapter files does not raise this warning, so you are not nagged to run `adapter upgrade` for a re-stamp that would touch no managed content. The warning fires only when the desired output has actually drifted (or when the agent profile can't be read, so equivalence can't be proven — in which case it is kept conservatively).

When you do see it, inspect the plan before writing:

```sh
code-pact adapter upgrade <agent> --check --json
# Read plan[] — managed-clean files appear as action:update,
# managed-modified files as action:refuse.

code-pact adapter upgrade <agent> --write
# Safe for managed-clean. Refuses managed-modified unless you also
# pass --accept-modified (the only flag that overwrites local edits).
```

See [`docs/upgrading.md`](upgrading.md) for the upgrade path (the alpha-era detail is archived in `migration.md`).

## Expected warnings around non-interactive setup

If you ran `code-pact init --non-interactive --agent <agent> --locale <locale>` from CI or a script, the project does not have generated instruction files or a pinned model version yet. `code-pact validate --json` then reports two warnings as expected state:

| Code              | Severity | Why it fires                                                                                                                                                                                   |
| ----------------- | -------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `ADAPTER_MISSING` | warning  | The enabled agent's instruction files (e.g. `CLAUDE.md`) have not been generated yet. Run `code-pact adapter install <agent> --model <version>` to create them.                                |
| `ADAPTER_STALE`   | warning  | `adapter install <agent>` was called without `--model <version>`, so the model profile is not pinned. Re-run `adapter install <agent> --model <version>` (e.g. `--model opus-4.7`) to silence. |

`BRIEF_MISSING` and `CONSTITUTION_PLACEHOLDER` do **not** fire on a fresh project — both are gated on a real (non-`TUTORIAL`) phase existing, so they stay quiet until the project has started real work. Once a phase exists, `BRIEF_MISSING` fires if `design/brief.md` is still absent (it is optional — `init` never creates it) and `CONSTITUTION_PLACEHOLDER` fires if the constitution is still the template. Resolve both from CI with the non-interactive `plan brief` / `plan constitution` modes (`--from-file <yaml>`, `--stdin`, or the flag forms — see [maintainers/operations.md § Non-interactive `plan brief` / `plan constitution`](maintainers/operations.md#non-interactive-plan-brief--plan-constitution-v16-p17)).

These are intentionally warnings, not errors — `validate` still exits 0. CI scripts that require a clean run can either fix the underlying state or pass `--strict` only after deciding to treat them as failures.

A separate `STATUS_DRIFT done-but-design-not-done` warning from `plan analyze --json` is also expected after any `task complete` until the design YAML's `status` field is flipped to `done`. `task complete` records progress, but does not mutate design intent. `code-pact task finalize <task-id> --write` (single task) or `code-pact phase reconcile <phase-id> --write` (whole phase) mechanizes the flip; the warning's `details.remediation` field carries the exact command. `code-pact task runbook <task-id> --json` (single task) or `code-pact phase runbook <phase-id> --json` (whole phase) also surfaces the same recommendation — runbook is read-only and never executes anything. See [maintainers/operations.md § `task complete` vs `design/`](maintainers/operations.md#task-complete-vs-design-v10-contract), [`docs/concepts/finalization-reconciliation.md`](concepts/finalization-reconciliation.md), and [`docs/concepts/runbook.md`](concepts/runbook.md).

## `DECISION_REQUIRED` from `task record-done`

The task (or its phase) is `requires_decision: true`, and the [decision gate](concepts/decision-gate.md) cannot resolve an **accepted** ADR for it. `task record-done` skips verification commands, so this gate is the only thing standing between a non-`task complete` completion path (external completion or a `record_only` task) and a `done` event — it is **not** bypassable. No progress event is recorded (exit 2).

```sh
code-pact task record-done <task-id> --evidence "PR #123" --json
# → error.code: DECISION_REQUIRED
# Inspect why: data.via ("decision_refs" | "filename-scan") and
# data.considered[] (each ADR with its status + acceptance).
```

Recovery: make an ADR for the task **accepted**.

- If `data.via` is `"filename-scan"`, create or edit `design/decisions/<task-id>.md` (the `data.expected_pattern`) so its `**Status:**` line reads `accepted`.
- If `data.via` is `"decision_refs"`, **every** path in the task's `decision_refs` must resolve to an `accepted` ADR (all-must-be-accepted). Fix the ones `data.considered[]` shows as `blocked` / `empty` / `missing` / `unknown_status` / `unsafe_path` / `unreadable`. For `unsafe_path`, the reference escapes the project root (`..`, an absolute path, or a symlink out) and is never read — replace it with a safe repo-relative path that stays inside the project (normally under `design/decisions/`).

The gate is the same one `verify` and `task complete` enforce, and it reads the ADR's status (see the [decision-gate concept](concepts/decision-gate.md)). To generate `proposed` stubs to fill in, import with `--scaffold-decisions`.

## `ADR_STATUS_UNRECOGNIZED` from `plan lint --include-quality`

An ADR in `design/decisions/` declares a status word the gate doesn't recognize — almost always a typo like `**Status:** acceptd`. The gate treats an unrecognized status as **not accepted**, so the decision stays blocked even though you meant to accept it. Advisory only (`affects_exit: false`); never fails the lint.

```sh
code-pact plan lint --include-quality --json
# → issues[] entry with code ADR_STATUS_UNRECOGNIZED
# details.status        — the offending word (e.g. "acceptd")
# details.status_source — "frontmatter" or "bold-line": which one to fix
```

Recovery: fix the status word to one of `accepted` / `proposed` / `draft` / `rejected` / `superseded`. `details.status_source` tells you whether the typo is in the YAML frontmatter `status:` or the body `**Status:**` line (frontmatter wins when both are present).

## `CONTROL_PLANE_NOT_DRIVEN` from `doctor`

`doctor` noticed the project has real (non-TUTORIAL) tasks and uncommitted git changes, but the progress ledger has never recorded a `started`/`done` event for a non-TUTORIAL task — i.e. the scaffold is in place but the loop isn't being driven. Advisory only (`severity: warning`; never fails `doctor`).

Recovery — pick whichever matches reality:

- **Drive the loop**: `code-pact task prepare <task-id> --agent <agent> --json`, then `task start`.
- **Record completion without `task complete`**: for external completion _or_ the `record_only` lane after you ran the project's verification by hand, `code-pact task record-done <task-id> --evidence "..."` (records a `done` with `source: external`; the decision gate still applies).
- **Silence it** (you knowingly aren't driving this project through code-pact): add to `.code-pact/doctor.yaml`:
  ```yaml
  disabled_checks:
    - CONTROL_PLANE_NOT_DRIVEN
  ```

It is a **silent skip** outside a git repo or when git isn't installed, so it never fires in CI sandboxes that aren't checkouts.

## `CONTROL_PLANE_BRANCH_NOT_DRIVEN` from `doctor` / `validate --base-ref`

The PR branch changed real code (vs the base ref's merge-base) but added **no** `started`/`done` event for a **known** non-TUTORIAL task to the committed ledger (legacy `progress.yaml`, `state/events/**`, or `state/archive/event-packs/**`) — code changed without driving the loop. Unlike `CONTROL_PLANE_NOT_DRIVEN` (which looks at the uncommitted working tree and so never fires in CI after a clean checkout), this is branch-diff based and is meant for PR CI. It runs **only** when `--base-ref` is supplied, and is advisory (`severity: warning`); pair it with `validate --strict` to make it a gate.

```sh
code-pact validate --strict --base-ref origin/main --json
# → CONTROL_PLANE_BRANCH_NOT_DRIVEN when real, non-excluded files
#   changed but no known non-TUTORIAL task got a started/done event
#   on the branch.
```

Recovery — pick whichever matches reality:

- **Drive the loop**: `code-pact task prepare <task-id> --agent <agent> --json`, then `task start` / `task complete`, and **commit the new event file(s)** under `.code-pact/state/events/` (the gate reads the committed ledger, not the working tree).
- **Record completion without `task complete`**: for external completion _or_ the `record_only` lane after verification, `code-pact task record-done <task-id> --evidence "..."`, then commit.
- **Exempt docs/config-only paths** the team agrees don't need the loop, in `.code-pact/doctor.yaml`:
  ```yaml
  control_plane_branch_not_driven:
    exclude_globs:
      - "docs/**"
      - "**/*.md"
  ```
- **Silence it**: add `CONTROL_PLANE_BRANCH_NOT_DRIVEN` to `disabled_checks`.

**Precondition.** The gate reads the **committed** ledger — the per-event files under `.code-pact/state/events/`, the event packs under `.code-pact/state/archive/event-packs/` (after compaction the history can live entirely in packs), **and** the legacy `.code-pact/state/progress.yaml`. `init` ignores only the machine-local / derived subset of `.code-pact/` (`/.code-pact/locks/`, `/.code-pact/cache/`, plus `/.local/` and `/.context/`), so by default the ledger is committable — commit it and the gate works. The check **silently skips** when none of the event files, event packs, or `progress.yaml` is git-tracked (e.g. you deliberately ignore `.code-pact/` — then `git add -f .code-pact/state/events/ .code-pact/state/archive/event-packs/ .code-pact/state/progress.yaml`) or when git/merge-base is unavailable. `validate` also needs the project config (`.code-pact/project.yaml`, agent/model profiles) in the CI checkout. See [Running code-pact in CI](workflows/ci.md) for the copy-paste GitHub Actions workflow, and [`docs/cli-contract.md` § `doctor`](cli-contract.md#--base-ref-and-ci-branch-drift-gating-v126-p34) for the `--base-ref` contract and the precondition.

## `ADR_ACCEPTED_BODY_THIN` from `plan lint --include-quality`

An `accepted` ADR in `design/decisions/` has an empty-stub body — an accepted decision with no recorded reasoning. The check is **structure-independent** (no heading-name matching): it fires only when the substantive body (frontmatter removed, status line + h1 title stripped, whitespace normalized) is below an internal threshold **and** the body has zero `##` (h2) headings. So a short-but-structured or long-but-heading-free ADR never fires. Advisory only (`affects_exit: false`); it does not change the decision gate.

```sh
code-pact plan lint --include-quality --json
# → issues[] entry with code ADR_ACCEPTED_BODY_THIN
# details.body_chars     — substantive body length measured
# details.heading_count  — number of h2 headings found (0 to fire)
```

Recovery: add the decision and its rationale to the ADR body, or — if it isn't actually decided yet — revert its `**Status:**` to `proposed` (then the [decision gate](concepts/decision-gate.md) correctly blocks completion until it's accepted with real content). A file that is just a `**Status:** accepted` line is exactly the stub this surfaces; a 0-byte empty file and `proposed`/`draft` ADRs are not flagged.

## `ADR_COMMITMENTS_EMPTY` from `plan lint --include-quality`

An **accepted** ADR that **resolves** a `requires_decision` task's [decision gate](concepts/decision-gate.md) records no implementation commitments — it has no `## Implementation commitments` section, or the section is present but has zero GFM checkbox items (`- [ ]`, `- [x]`, `* [ ]`, `* [x]` — checked **and** unchecked all count toward `item_count`). The decision is settled, but the downstream work it implies is unrecorded. (Only a gate that actually resolves is in scope: a partially-accepted explicit `decision_refs` set is unresolved and surfaces `TASK_DECISION_UNRESOLVED` instead.)

This is a **warning, not a blocker**: `affects_exit: false`, so it never changes the exit code, **including under `--strict`**. It is scoped to accepted ADRs that **resolve** a gated task's gate, so unreferenced ADRs and unresolved (partially-accepted) gates never fire.

```sh
code-pact plan lint --include-quality --json
# → issues[] entry with code ADR_COMMITMENTS_EMPTY
# file                  — the ADR path (there is no `path` field; the subject is ADR content)
# task_id / phase_id    — the gated task that references the ADR
# details.has_section   — false = no section; true = section present
# details.item_count    — number of checkbox items (0 to fire)
```

Recovery: add a `## Implementation commitments` checkbox list to the accepted ADR — the concrete downstream work the decision implies (`- [ ]` for work to do, `- [x]` for work already satisfied). If the decision genuinely implies no downstream work, record that explicitly as a checked item: `- [x] No downstream implementation work.` — use this **only when there truly is none**, not merely to silence the advisory (the point of recording commitments is to make the consequences deliberate).

## `PHASE_DOCS_WRITE_NO_DOC_CHECK` from `plan lint --include-quality`

A **not-yet-`done`** phase has a task whose `writes` includes a public doc that `pnpm check:docs` guards (a `docs/**` file or a root-level public `.md`), but the phase's `verification.commands` run no doc check. The phase will edit public docs without verifying them — exactly the docs-drift this guard exists to stop.

This is a **warning, not a blocker**: `affects_exit: false`. CHANGELOG.md is excluded (it is not scanned by `check:docs`), `design/**` is excluded (validated by `validate` / `plan lint`), and `done` phases are never flagged (it is a forward-looking guard — a frozen phase can't be changed).

```sh
code-pact plan lint --include-quality --json
# → issues[] entry with code PHASE_DOCS_WRITE_NO_DOC_CHECK
# file              — the phase YAML path
# phase_id / task_id — the phase and the task whose writes triggered it
# details.doc_write — the offending public-doc write target
```

Recovery: add a doc check (`pnpm check:docs`, or `check:doc-links` / `check:doc-invariants`) to the phase's `verification.commands` so the doc edits are verified; or, if the declared doc write is stale, remove it from the task's `writes`.

## Context Fit advisories from `plan lint --include-quality`

The four Context Fit advisories flag likely **context-size risk** before a task runs. They appear **only** under `--include-quality`, are **absent** without it, and every one is `affects_exit: false` — they never change the exit code, even under `--strict`. Thresholds are deterministic byte/count values; the pass is local and deterministic (no model / tokenizer / summarization / compression / network), changes no context pack content, and applies no budget automatically.

These are **readiness signals, not correctness failures**. A large context pack, a large declared decision, or a broad `reads` glob can all be legitimate — the advisories help you notice size risk early, not block work or force premature micro-optimization.

```sh
code-pact plan lint --include-quality --json
# → issues[] entries (all affects_exit: false)
```

- **`TASK_CONTEXT_PACK_LARGE`** — the task's **natural** (pre-elision) context pack exceeds the `balanced` budget (60000 bytes). `details.natural_bytes` / `details.threshold_bytes` / `details.recommended_profile` (`"wide"`). Reuses the `natural_bytes` explain metric. Recovery (optional): pass `--context-budget wide` when building the pack, or split the task if its scope is genuinely too broad. Needs a resolvable project `default_agent` for the pack build; skipped otherwise.
- **`TASK_CONTEXT_BUDGET_UNACHIEVABLE`** — the deterministically recommended budget (the default agent's same-name `context_budget` override when available, else the built-in fallback — the same byte value `recommend` surfaces) cannot fit even after maximal eligible elision: `minimum_achievable_bytes > budget_bytes`. `details.profile` / `details.budget_bytes` / `details.minimum_achievable_bytes` (the **same floor `CONTEXT_OVER_BUDGET` reports**). Recovery (optional): use a wider profile or split the task. It does not change the recommendation or fail lint. Needs a resolvable `default_agent`; skipped otherwise.
- **`TASK_DECLARED_DECISION_LARGE`** — a `decision_refs` entry points to a decision body larger than the `tight` budget (30000 bytes), large enough to dominate a tight pack. `details.path` / `details.bytes` / `details.threshold_bytes`. This is **not** an ADR-quality error — do not delete the ADR; consider splitting follow-up tasks, using a wider profile, or confirming the task scope justifies the large reference. Unsafe/missing refs are reported by `TASK_DECISION_REF_UNSAFE_PATH` / `TASK_DECISION_REF_NOT_FOUND` instead.
- **`TASK_READS_MATCH_TOO_MANY`** — a `reads` glob matches more than 100 files and may inflate context planning cost. `details.glob` / `details.match_count` / `details.threshold_count`. Recovery (optional): narrow the glob if the task can be scoped more precisely. Broad reads can be valid for cross-cutting refactors.

## `EVENT_FILE_ID_MISMATCH` from `doctor` / `plan lint`

A per-event progress-ledger file under `.code-pact/state/events/` failed the
filename↔content invariant. The filename is `<at-compact>-<id>.yaml`, where the
`<id>` suffix is the sha256 content id and the `<at-compact>` prefix is the
event's normalized `at`. The check fails when any of these disagree: the
recomputed content id does not match the filename's id suffix, the event's `at`
does not match the filename prefix, or its stored `id` disagrees with the
recomputed content id. This is fail-closed — a corrupt, partial, or hand-edited
event file is never read or written over silently.

```sh
# The message names the offending file, e.g.
#   Event file 2026…-<id>.yaml: content id (<a>) does not match filename id (<b>)
git checkout -- .code-pact/state/events/<file>   # restore it if it was committed
# or, if it is a stray / corrupt local file:
rm .code-pact/state/events/<file>
```

Do **not** hand-edit event files — they are content-addressed: the filename
embeds the event's timestamp prefix and the sha256 content id suffix
(`<at-compact>-<id>.yaml`). To change recorded progress, append a new event
via the `task` verbs. On the strict-loader commands the same corruption surfaces
as a command failure — `plan analyze` → `PLAN_ANALYZE_FAILED`, `plan migrate` →
`PLAN_MIGRATE_FAILED`, `task *` / `verify` abort — with this diagnostic carried in
`error.message`.

## `PROGRESS_EVENT_CONFLICT` from `doctor` / `plan analyze`

The merged ledger contains incompatible lifecycle events for one task — e.g. two
branches that each recorded `done` for the same task, a second `started` while it
was already `started`, or a `done` / `blocked` with no intervening `resumed`. The
reducer still derives a state, but the conflict is **surfaced, not silently
resolved**.

```sh
code-pact doctor --json | jq '.data.issues[] | select(.code=="PROGRESS_EVENT_CONFLICT")'
# Inspect details.events[] for the named task, decide which event is correct,
# then remove or correct the other. For a per-event ledger entry find the file as
# .code-pact/state/events/*-<event_id>.yaml; for a legacy ledger, reconcile the
# matching entry in .code-pact/state/progress.yaml — then re-run doctor / plan
# analyze to confirm.
```

**Who collided.** The issue carries a
structured `details.events[]` naming the conflicting side(s) — `{ event_id,
status, author?, at }` (usually two, the establishing event and the offender; one
when the first event for a task is itself invalid) — so you (and an agent) see
_who_ produced each event without opening the files (`author` is omitted for
legacy / capture-off events). `event_id` is the **content id**, and where the
offending event lives depends on the ledger:

- **Per-event ledger** — `event_id` is the _suffix_ of the filename `<at-compact>-<event_id>.yaml`, not the whole name; locate it with `.code-pact/state/events/*-<event_id>.yaml`.
- **Legacy `.code-pact/state/progress.yaml`** — there is **no** per-event file; reconcile the matching entry in `progress.yaml` (or migrate the legacy ledger first).

The same conflict also shows up in the team overview:

```sh
# Same facts, from the activity overview (PROGRESS_EVENT_CONFLICT only):
code-pact status --json | jq '.data.conflicts[]'
# Each side: { event_id, status, author?, at }. Decide which is correct, then
# remove/correct the other event — for a per-event ledger entry the file is
# .code-pact/state/events/*-<event_id>.yaml; for a legacy ledger, the matching
# entry in .code-pact/state/progress.yaml — and re-run.
```

Advisory by default (`severity: warning`); `validate --strict` promotes it to a
failure so CI can gate on it. It is **not** auto-resolved because a same-task
concurrent edit is a genuine collaboration conflict a human should adjudicate.

## `CONTROL_PLANE_GITIGNORED` from `doctor`

Your `.gitignore` keeps part of the shared control plane out of git. The
`message` names which areas — any of `project.yaml`, `agent-profiles/`,
`model-profiles/`, `state/baselines/`, or `state/events/` (the progress ledger).
Whatever it names **never reaches git**, so that state stays local: a teammate or
a clean checkout misses whatever is ignored — project config, profiles,
baselines, or the progress ledger. **If the ledger itself is ignored**, the
`CONTROL_PLANE_BRANCH_NOT_DRIVEN` CI gate _also_ silently skips because it has no
tracked ledger to read (a config/profile/baseline-only ignore does not affect
that gate).

The usual cause is a **blanket `/.code-pact/` ignore**, but a **file-scoped** rule
like `/.code-pact/state/events/*.yaml` is just as dangerous — the `events/`
directory is not ignored, yet every _new_ event file is. `init` _merges_ its
narrow entries into an existing `.gitignore` and **never deletes your lines**, so a
pre-existing rule survives and overrides them. `doctor` reports this
authoritatively: it asks git (`git check-ignore --no-index`) for a representative
_file_ in each shared area, so a force-added `.gitkeep` does not mask it and a
`!`-negation re-include is honoured.

```sh
# Confirm the diagnosis the same way doctor does (rule-based, index-independent).
# Probe a representative NEW file in each shared area — exit 0 prints the ignored ones:
git check-ignore --no-index \
  .code-pact/project.yaml \
  .code-pact/agent-profiles/x.yaml \
  .code-pact/model-profiles/x.yaml \
  .code-pact/state/baselines/x.json \
  .code-pact/state/events/19700101T000000Z-x.yaml
# (no output + exit 1 = nothing ignored = ok)
```

Add `-v` to see _which_ rule matches, but read it carefully: a printed `!`-negation
line can mean a path is actually **re-included** (not ignored). `code-pact doctor`
(`CONTROL_PLANE_GITIGNORED`) is the authority — it interprets negations the same way.

Fix it by **narrowing** the rule yourself (neither `init` nor `doctor` edits your
`.gitignore`). Keep only the local/derived subset ignored:

```gitignore
/.code-pact/locks/
/.code-pact/cache/
/.local/
/.context/
```

Remove or narrow the offending rule (the blanket `/.code-pact/` line, or the
file-scoped one the `-v` output named), then commit the shared state
(`project.yaml`, `agent-profiles/`, `model-profiles/`, `state/baselines/`,
`state/events/`) and re-run `code-pact doctor` to confirm. See the shared-vs-local
table in [State file write guarantees](cli-contract.md#state-file-write-guarantees).

Advisory (`severity: warning`): `doctor` and default `validate` do not fail on
it, but `validate --strict` promotes it to exit-relevant (like other doctor
warnings), so CI can gate on it. If the repo is intentionally solo/throwaway,
silence it via `.code-pact/doctor.yaml` (`disabled_checks: [CONTROL_PLANE_GITIGNORED]`).

## `LOOP_MEMORY_*` from `doctor`

Loop memory is a bounded local cache under
`.code-pact/cache/loop-memory/v1/episodes/`. It is useful only inside one
checkout and must not become shared project state. `doctor` reports three
advisories:

| Code                               | Meaning                                                                     | Fix                                                                                 |
| ---------------------------------- | --------------------------------------------------------------------------- | ----------------------------------------------------------------------------------- |
| `LOOP_MEMORY_CACHE_NOT_GITIGNORED` | `/.code-pact/cache/` is not ignored.                                        | Add `/.code-pact/cache/` to `.gitignore`.                                           |
| `LOOP_MEMORY_TRACKED`              | One or more files under `.code-pact/cache/loop-memory/` are tracked by git. | Remove those local cache files from version control; do not delete unrelated state. |
| `LOOP_MEMORY_PATH_UNSAFE`          | The cache path resolves through a symlink or outside the project.           | Replace it with a normal directory under `.code-pact/cache/loop-memory/`.           |

Use aggregate maintenance commands; they do not print episode bodies:

```sh
code-pact memory status --json
code-pact memory prune --json
code-pact memory prune --write --json
```

`memory prune` is dry-run unless `--write` is present. `doctor` never deletes
cache files and never runs `git rm`; it reports cache ignore, Git tracking, and
path-safety problems, not individual corrupt episode files.
If `memory prune --write` returns `MEMORY_PRUNE_CONFLICT`, inspect
`data.partial_applied` and `data.deleted_count`. A preflight conflict deletes
nothing; a post-preflight conflict may have deleted earlier candidates.
`deleted_count` counts only successful unlinks by that invocation. A candidate
that another local process removed after the final identity read is skipped and
not counted. If `memory prune --write` returns `MEMORY_PRUNE_FAILED`,
`data.system_code` names the platform cause when available, and the JSON may
also include `data.partial_applied` and `data.deleted_count` when deletion had
begun. The final identity-read to unlink window is not a portable filesystem
compare-and-swap, so run `code-pact memory status` and dry-run
`code-pact memory prune` again before retrying `--write`.

`memory status` may count corrupt local cache entries. That includes oversized
files, invalid UTF-8, invalid JSON, schema-invalid episodes, files whose name
does not match the canonical episode payload, and nonregular entries such as
symlinks or directories. These entries are ignored by retention planning and
local advisory consumers; remove them manually only after confirming they are
local cache, not shared project state. `corrupt_bytes` is only the safely
measured regular-file subset, including invalid UTF-8 files; use
`corrupt_unmeasured_count` to see how many corrupt entries were not measured.

`task complete` can return two advisory warning codes without changing the
verification result or exit code:

| Code                         | Meaning                                                                           |
| ---------------------------- | --------------------------------------------------------------------------------- |
| `LOCAL_MEMORY_WRITE_SKIPPED` | The episode was not recorded.                                                     |
| `LOCAL_MEMORY_PRUNE_SKIPPED` | The episode was recorded, but best-effort retention maintenance did not complete. |

`memory` operational errors use stable exit-1 JSON codes under `--json`:
`MEMORY_PATH_UNSAFE`, `MEMORY_READ_FAILED`, `MEMORY_PRUNE_CONFLICT`, and
`MEMORY_PRUNE_FAILED`.

## Id collisions & mismatches (collaboration)

These are the **clean-but-wrong merge** class: two contributors on separate
branches each mint the same `P<N>` / `P<N>-T<M>` id in separate files, git
auto-merges with no conflict, and the corruption only surfaces when a check runs.
They are **errors** (they fail `plan lint` / `doctor` by default — no `--strict`
needed), and each now carries a structured `recovery` object (`recovery.manual_action`
= the edit, `recovery.confirm` = the re-verify command, `recovery.reference`) in
JSON so an agent can act without parsing prose. The manual fix is always the same
shape: **give one of the colliding things a unique id, update anything that
references it, then re-run the check.**

### `DUPLICATE_PHASE_ID` from `plan lint` / `doctor`

Two roadmap entries (and their phase files) claim the same phase id — e.g. both
branches minted `P7`. The message names both files.

```sh
code-pact plan lint --json | jq '.data.issues[] | select(.code=="DUPLICATE_PHASE_ID")'
# .recovery.manual_action names the exact edit; .recovery.confirm is the re-verify
# command; .file is one colliding file.
```

Fix: pick one phase, give it a unique id — edit its `id:` field and update its
entry in `design/roadmap.yaml` (rename the file/path too if the filename embeds
the old id or to keep the `<id>-<slug>.yaml` convention). If that phase has tasks
whose ids use the **old phase prefix** (e.g. `P7-T1`), rename those task ids too
and update any `depends_on` that references them — then re-run
`code-pact plan lint` and address any follow-up `TASK_ID_PHASE_PREFIX` /
`DUPLICATE_TASK_ID`. If the two files are actually the **same** phase merged from
two branches, delete the duplicate file and its roadmap entry instead of
renumbering.

### `DUPLICATE_TASK_ID` from `plan lint` / `doctor`

One task id appears under two phases. The message names both phases **and their
files** — the file path disambiguates the compound case where two phase files
also share a phase id (in that case, fix `DUPLICATE_PHASE_ID` first).

Fix: renumber one task — change its `id:` under that phase's `tasks:`, **and any
`depends_on` entry (in any task) that references the old id**. Note `decision_refs`
/ `acceptance_refs` are **file paths**, not task-id references — only touch them if
a path intentionally embeds the old id. If **progress events already exist** for
the duplicated id, check which task they belong to _before_ editing — do not
blindly rewrite event files. Then re-run `code-pact plan lint`. If the task was
duplicated by a merge, delete the redundant copy instead.

### `PHASE_ID_MISMATCH` from `plan lint` / `doctor`

A phase file's inner `id:` does not match the id the roadmap uses to reference it
(`<file> has id="<actual>" but roadmap expects "<expected>"`) — usually a phase
file cloned without updating its id, or a half-resolved merge.

Fix one of the two to agree: set `id: <expected>` inside the file, **or** change
that file's entry id in `design/roadmap.yaml` to `<actual>`. Then re-run
`code-pact plan lint`.

### `AMBIGUOUS_PHASE_ID` and `AMBIGUOUS_TASK_ID` (fail-closed id resolution)

A command tried to **resolve** an id that two files (phase) or two phases (task)
claim, and **failed closed** (exit 2) rather than silently acting on the first
match. The colliding locations are in **`data.phases[]`**
(`AMBIGUOUS_TASK_ID`: the phase ids that both define the task; `AMBIGUOUS_PHASE_ID`:
the phase file paths).

```sh
code-pact task prepare P7-T1 --agent claude-code --json | jq '{error, data}'
# { "error": { "code": "AMBIGUOUS_TASK_ID", "message": "..." },
#   "data": { "phases": ["P3","P7"] } }
```

This is a symptom of an unresolved `DUPLICATE_PHASE_ID` / `DUPLICATE_TASK_ID`:
resolve that first (sections above) — renumber the duplicate and re-run
`code-pact plan lint` until clean — then retry the original command. The tool
refuses to guess which one you meant, by design.

## One-shot execution errors from `task execute`

These codes are emitted by the experimental `code-pact task execute` command. The
runtime attempts a compare-and-swap rollback on `verification_failed`,
`execution_scope_violation`, `rollback_incomplete`, and known Code Pact edits.
Unknown executor or external mutations (reported as `executor_mutated_worktree`
with `data.rollback: "not_attempted"`) are never rolled back because their
provenance cannot be proven. The runtime never resets HEAD or unstages index
changes.

| Code                        | Usually means                                                                                                                                                                                                                          | Start here                                                                                                                                                  |
| --------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `EDIT_REJECTED`             | The executor returned a `replace_exact` payload that could not be applied (stale SHA, path not in `writes`, malformed replacement, resulting source over `MAX_SOURCE_BYTES` (`8192`) as `RESULTING_SOURCE_TOO_LARGE`, or SHA mismatch) | Fix the executor output; ensure the task's `writes` and the file SHA match; reduce replacement size if it would exceed the source byte limit                |
| `EXECUTION_BLOCKED`         | The executor reported it cannot modify the file                                                                                                                                                                                        | Update the task or executor to handle the blocker                                                                                                           |
| `EXECUTION_INELIGIBLE`      | The task is not eligible for one-shot execution                                                                                                                                                                                        | Change the task to read+write a single existing file and ensure it is `planned`/`started`                                                                   |
| `EXECUTOR_FAILED`           | The external executor exited non-zero, timed out, emitted malformed/oversized JSON, or an unsupported `kind`/unknown keys; `data.reason` is bounded to 2,048 UTF-8 bytes                                                               | Check the executor path, permissions, timeout, and stdout size (< 24576 bytes); verify `expected_file_sha256` is 64 lowercase hex and emit no extra keys    |
| `ROLLBACK_FAILED`           | The file could not be restored after a verification failure                                                                                                                                                                            | Inspect the working tree, HEAD, and index manually and repair before retrying                                                                               |
| `ROLLBACK_STALE_FILE`       | The source file changed concurrently after the edit, so rollback refused to overwrite it                                                                                                                                               | Resolve the concurrent change and retry with a clean working tree                                                                                           |
| `VERIFICATION_FAILED`       | The verification command failed after the source file was edited; the source is rolled back                                                                                                                                            | Fix the failing verification command and retry                                                                                                              |
| `ROLLBACK_INCOMPLETE`       | The source file was rolled back, but other unexpected working-tree, HEAD, or index changes remain                                                                                                                                      | Review `data.paths`, `data.head_changed`, `data.index_changed`, and `data.failure`, clean the repository, and retry                                         |
| `WORKTREE_NOT_CLEAN`        | The working tree (or HEAD/index) had changes before execution                                                                                                                                                                          | Commit or stash changes and retry                                                                                                                           |
| `EXECUTOR_MUTATED_WORKTREE` | The executor or an external process modified repository state (HEAD, index, worktree, or any file) before Code Pact applied its own edit; `data.rollback` may be `not_attempted` for unknown provenance                                | Fix the executor to only emit a `replace_exact`/`blocked` response; if `rollback` is `not_attempted`, review and clean the repository manually              |
| `EXECUTION_SCOPE_VIOLATION` | Verification or a side-effect altered files, HEAD, or the index outside the target source-file change                                                                                                                                  | Ensure verification commands are read-only and do not create artifacts; review `data.paths`, `data.rollback`, `data.head_changed`, and `data.index_changed` |
| `GIT_STATE_UNAVAILABLE`     | Git state could not be captured after a known Code Pact edit; `data.source_rollback` reports whether the source file was restored (`complete`/`stale`/`failed`/`not_needed`)                                                           | Inspect the repository, verify the source file matches the rollback report, and run `git status` manually before retrying                                   |
