# Token-Efficient Development

Code Pact development should reduce total input and rework for users without
creating an unbounded design-review loop for Code Pact itself.

## Scope Closure

For one implementation scope, use at most:

- one implementation review
- one fix-confirmation review

The first review must present all blockers it can find for the current scope.
Each blocker must include severity, reproduction condition, impact, affected
file, fix condition, and required test.

The second review is limited to confirming the first review's blockers. New
findings become backlog unless the fix introduced a regression, security issue,
data loss, public API break, or CI failure. Any exception needs a reproducer.

Do not run a third review for the same scope unless an automated test fails and
the issue is a release blocker.

## Blockers

Release blockers are correctness failures, security issues, data loss, public
contract breaks, required test or CI failures, and boundedness invariant
failures.

Backlog items include naming improvements, future extensions, ahead-of-time
design for unimplemented features, theoretical portability edges, and
unmeasured performance concerns. Backlog does not block the current scope.

## Artifact Identity

Review requests include a tree hash. If the same tree hash is submitted again,
the review result is `unchanged`; do not repeat the same review.

## Agent Self-Review

Before external review, run one self-review and report one summary covering:

- declared writes match the diff
- no out-of-scope feature was added
- each acceptance criterion has a test or stated evidence
- public JSON output was checked where affected
- default output is byte-identical where required
- success, failure, missing cache, and corrupt cache paths are covered where in scope
- `git diff --check` passes
- required verification commands pass

Do not split review into iterative "what should I check next" prompts.

## Development-Efficiency Gate

Run this before external review and during release preparation:

```sh
pnpm check:development-efficiency
```

Before starting a planned architecture or docs-only task, run the prospective
gate:

```sh
pnpm check:development-efficiency -- --next-task <task-id>
```

The check uses `P72-T4` as the conceptual baseline. After that baseline, two
consecutive current design-only tasks fail with `DEVELOPMENT_DESIGN_LOOP_EXCEEDED`.
A runtime, test, or script implementation task resets the current streak to
zero; the historical maximum remains diagnostic only. Even when the current
streak is already 2, a prospective runtime/test/script task passes because it
resets the streak to zero. Design-only includes `design/`, `docs/`,
`.code-pact/`, root-level Markdown files, `LICENSE`, and `NOTICE` when no
`src/`, `tests/`, or `scripts/` write is declared. `release:check` runs this
gate.

When completed phases and their progress events are compacted into archive
bundles, the gate uses a tracked checkpoint (`scripts/development-efficiency-checkpoint.json`)
containing the accumulated counters and the exact terminal event identity for
the baseline and checkpoint. Events after the checkpoint are classified from
active task definitions. An event after the checkpoint without an available task
definition is a configuration failure; it is never silently ignored. Before
archiving tasks completed after the checkpoint, maintainers must advance the
checkpoint while those task definitions are still available.

This page is linked from [CONTRIBUTING.md](../../CONTRIBUTING.md) and
[Maintainer operations](operations.md) so the workflow is discoverable.
