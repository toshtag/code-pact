// P39 — Root-cause-first completion errors.
//
// task complete must name the real cause on the PRIMARY error face: an
// additive `error.cause_code` plus an actionable `error.message`, while
// `error.code` stays VERIFICATION_FAILED (exit 1) and the P32 `data` fields
// are left where they are (not duplicated into `error`). These tests spawn the
// built CLI and exercise the decision-gate path (no ADR / proposed ADR) and the
// command-failure path. See design/decisions/root-cause-completion-errors-rfc.md.
import { describe, it, expect, beforeAll, beforeEach, afterEach } from "vitest";
import {
  mkdtemp,
  rm,
  readFile,
  writeFile,
  mkdir,
  readdir,
} from "node:fs/promises";
import { execSync } from "node:child_process";
import { join } from "node:path";
import { tmpdir } from "node:os";
import { parse as parseYaml, stringify as stringifyYaml } from "yaml";
import {
  run as cliRun,
  ensureCliBuilt,
  type RunResult,
} from "../helpers/cli.ts";

let tmpDir: string;

function run(args: string[]): RunResult {
  return cliRun(tmpDir, args);
}

type Envelope = {
  ok: boolean;
  error: { code: string; message: string; cause_code?: string };
  data: {
    failed_checks: string[];
    first_failure: { name: string; reason: string } | null;
    verify: { ok: boolean; checks: { name: string; ok: boolean }[] };
  };
};

/** Resolve the on-disk path of phase P1 (the slug suffix depends on --name). */
async function phaseP1Path(): Promise<string> {
  const dir = join(tmpDir, "design", "phases");
  const entries = await readdir(dir);
  const file = entries.find(e => e === "P1.yaml" || e.startsWith("P1-"));
  if (!file)
    throw new Error(`P1 phase file not found in ${entries.join(", ")}`);
  return join(dir, file);
}

/**
 * Add phase P1 with a single task P1-T1 (full schema, status planned),
 * a passing verify command, then apply `patch` to the task before writing.
 */
async function setupTask(
  patch: (task: Record<string, unknown>) => void,
  commands: string[] = ["true"],
): Promise<void> {
  expect(
    run([
      "init",
      "--non-interactive",
      "--locale",
      "en-US",
      "--agent",
      "claude-code",
      "--json",
    ]).code,
  ).toBe(0);
  expect(
    run([
      "phase",
      "add",
      "--id",
      "P1",
      "--name",
      "Foundation",
      "--objective",
      "Foundation",
      "--weight",
      "10",
      "--json",
    ]).code,
  ).toBe(0);

  const phasePath = await phaseP1Path();
  const doc = parseYaml(await readFile(phasePath, "utf8")) as Record<
    string,
    unknown
  >;
  doc.verification = { commands };
  const task: Record<string, unknown> = {
    id: "P1-T1",
    type: "feature",
    ambiguity: "low",
    risk: "low",
    context_size: "small",
    write_surface: "low",
    verification_strength: "weak",
    expected_duration: "short",
    status: "planned",
    description: "integration test task",
  };
  patch(task);
  doc.tasks = [task];
  await writeFile(phasePath, stringifyYaml(doc), "utf8");

  execSync("git init", { cwd: tmpDir, stdio: "ignore" });
  execSync("git config user.email test@example.com", {
    cwd: tmpDir,
    stdio: "ignore",
  });
  execSync("git config user.name Test", { cwd: tmpDir, stdio: "ignore" });
  execSync("git add .", { cwd: tmpDir, stdio: "ignore" });
  execSync("git commit -m init", { cwd: tmpDir, stdio: "ignore" });
  expect(run(["task", "lock", "P1-T1", "--json"]).code).toBe(0);
}

async function writeAdr(filename: string, body: string): Promise<void> {
  const dir = join(tmpDir, "design", "decisions");
  await mkdir(dir, { recursive: true });
  await writeFile(join(dir, filename), body, "utf8");
}

const GENERIC = `Verification failed for "P1-T1". progress.yaml was not modified.`;

describe("P39: task complete cause_code", () => {
  beforeAll(() => {
    ensureCliBuilt();
  });

  beforeEach(async () => {
    tmpDir = await mkdtemp(join(tmpdir(), "p39-cause-"));
  });

  afterEach(async () => {
    if (tmpDir) await rm(tmpDir, { recursive: true, force: true });
  });

  it("decision gate with no ADR -> cause_code DECISION_REQUIRED; progress.yaml unchanged", async () => {
    await setupTask(t => {
      t.requires_decision = true;
    });

    const progressPath = join(tmpDir, ".code-pact", "state", "progress.yaml");
    const before = await readFile(progressPath, "utf8");

    const res = run([
      "task",
      "complete",
      "P1-T1",
      "--agent",
      "claude-code",
      "--json",
      "--dry-run",
    ]);
    expect(res.code).toBe(1);
    const env = JSON.parse(res.stdout) as Envelope;

    expect(env.ok).toBe(false);
    // error.code unchanged (v1-stable); cause is additive.
    expect(env.error.code).toBe("VERIFICATION_FAILED");
    expect(env.error.cause_code).toBe("DECISION_REQUIRED");
    expect(env.error.message).toMatch(/accepted ADR/i);
    expect(env.error.message).not.toBe(GENERIC);
    // The decision cause embeds first_failure.reason so an agent reading only
    // `error` learns WHY the gate is unresolved (missing / proposed / etc.).
    expect(env.error.message).toContain(env.data.first_failure!.reason);

    // No error-side duplication of P32 data fields and no structured block.
    expect(env.error).not.toHaveProperty("failed_checks");
    expect(env.error).not.toHaveProperty("first_failure");
    expect(env.error).not.toHaveProperty("considered");
    expect(env.error).not.toHaveProperty("decision_check");

    // P32 detail still present in data.
    expect(env.data.failed_checks).toContain("decision");
    expect(env.data.first_failure?.name).toBe("decision");
    expect(
      env.data.verify.checks.some(c => c.name === "decision" && !c.ok),
    ).toBe(true);

    const after = await readFile(progressPath, "utf8");
    expect(after).toBe(before);
  });

  it("decision gate with a proposed (not accepted) ADR -> same cause_code, accepted required", async () => {
    await setupTask(t => {
      t.requires_decision = true;
    });
    await writeAdr(
      "P1-T1-proposal.md",
      "# RFC: P1-T1 decision\n\n**Status:** proposed\n\n## Decision\n\nNot yet accepted.\n",
    );

    const res = run([
      "task",
      "complete",
      "P1-T1",
      "--agent",
      "claude-code",
      "--json",
      "--dry-run",
    ]);
    expect(res.code).toBe(1);
    const env = JSON.parse(res.stdout) as Envelope;
    expect(env.error.code).toBe("VERIFICATION_FAILED");
    expect(env.error.cause_code).toBe("DECISION_REQUIRED");
    expect(env.error.message).toMatch(/accepted ADR/i);
  });

  it("command failure -> cause_code COMMANDS_FAILED; data backward-compatible", async () => {
    // No decision gate; the verify command fails. Run a REAL completion (not
    // --dry-run): --dry-run no longer executes verification commands (security
    // hardening), so the command-failure cause is exercised by an actual run. A
    // failed verify records no progress event, so this is still side-effect-free.
    await setupTask(() => {}, ["false"]);

    const res = run([
      "task",
      "complete",
      "P1-T1",
      "--agent",
      "claude-code",
      "--json",
    ]);
    expect(res.code).toBe(1);
    const env = JSON.parse(res.stdout) as Envelope;
    expect(env.error.code).toBe("VERIFICATION_FAILED");
    expect(env.error.cause_code).toBe("COMMANDS_FAILED");
    // The command cause embeds the failing command's reason in the message.
    expect(env.error.message).toMatch(/a verification command failed:/);
    expect(env.data.failed_checks).toContain("commands");
    expect(env.data.first_failure?.name).toBe("commands");
  });

  // P39 spec pin: verify runs `commands` before `decision`, so when BOTH fail
  // (a failing command AND a missing ADR), first-failure precedence makes the
  // command the cause. This is the accepted behavior — pinned so a future
  // reorder or a switch to priority-based selection is a conscious change.
  it("command + decision both fail -> COMMANDS_FAILED wins; both in failed_checks", async () => {
    await setupTask(
      t => {
        t.requires_decision = true;
      },
      ["false"],
    );

    // Real completion (not --dry-run): --dry-run previews commands rather than
    // executing them, so the command must actually run for `commands` to be the
    // first failure ahead of `decision`. A failed verify records nothing.
    const res = run([
      "task",
      "complete",
      "P1-T1",
      "--agent",
      "claude-code",
      "--json",
    ]);
    expect(res.code).toBe(1);
    const env = JSON.parse(res.stdout) as Envelope;
    expect(env.error.code).toBe("VERIFICATION_FAILED");
    expect(env.error.cause_code).toBe("COMMANDS_FAILED");
    expect(env.data.first_failure?.name).toBe("commands");
    expect(env.data.failed_checks).toContain("commands");
    expect(env.data.failed_checks).toContain("decision");
  });

  // P39-T2: human (non-JSON) parity. The plain-text path must also name the
  // cause and the rerun-after-fixing line for BOTH failure causes, so an agent
  // reading stderr is not left with only the generic message. The command-cause
  // human case is covered in cli.test.ts; this pins the decision cause.
  it("human output (decision failure): actionable headline + cause + rerun line", async () => {
    await setupTask(t => {
      t.requires_decision = true;
    });

    const res = run(["task", "complete", "P1-T1", "--agent", "claude-code"]);
    expect(res.code).toBe(1);
    // Headline is the actionable cause message, not the generic string.
    expect(res.stderr).toMatch(/requires an accepted ADR/i);
    expect(res.stderr).not.toBe(GENERIC);
    // The shared failure-summary lines below it.
    expect(res.stderr).toMatch(/cause: decision —/);
    expect(res.stderr).toMatch(
      /rerun after fixing: code-pact task complete P1-T1/,
    );
  });

  it("human output (command failure): actionable headline + cause + rerun line", async () => {
    await setupTask(() => {}, ["false"]);

    const res = run(["task", "complete", "P1-T1", "--agent", "claude-code"]);
    expect(res.code).toBe(1);
    expect(res.stderr).toMatch(/a verification command failed/i);
    expect(res.stderr).toMatch(/cause: commands —/);
    expect(res.stderr).toMatch(
      /rerun after fixing: code-pact task complete P1-T1/,
    );
  });

  // P39 contract boundary: error.cause_code is a `task complete`-only surface.
  // standalone `verify --json` uses the generic VERIFICATION_FAILED envelope
  // (ok:false, exit 1) and reports per-check results in data.checks. Crucially
  // its error carries NO cause_code — that enrichment (DECISION_REQUIRED /
  // COMMANDS_FAILED) is added only by `task complete`. Pinned so a future change
  // to verify's surface is a conscious decision.
  it("standalone verify failure has NO error.cause_code (cause_code is task complete-only)", async () => {
    await setupTask(t => {
      t.requires_decision = true;
    });

    const res = run(["verify", "--phase", "P1", "--task", "P1-T1", "--json"]);
    expect(res.code).toBe(1);
    const env = JSON.parse(res.stdout) as {
      ok: boolean;
      error?: { code?: string; cause_code?: string };
      data: { checks: { name: string; ok: boolean }[] };
    };
    // verify uses the generic VERIFICATION_FAILED envelope and reports the
    // failing check in data.checks — but it does NOT carry error.cause_code.
    expect(env.ok).toBe(false);
    expect(env.error?.code).toBe("VERIFICATION_FAILED");
    expect(env.error).not.toHaveProperty("cause_code");
    expect(env.data.checks.some(c => c.name === "decision" && !c.ok)).toBe(
      true,
    );
  });
});
