import { readFileSync, writeFileSync } from 'node:fs';
const resp = readFileSync('/tmp/P84-T1/codepact-initial-response.txt', 'utf8');
function extract(label) {
  const re = new RegExp(`---BEGIN ${label}---\\n([\\s\\S]*?)\\n---END ${label}---`);
  const m = resp.match(re);
  if (!m) throw new Error('missing ' + label);
  return m[1];
}
const tp = extract('task-progress.ts');
const driftCase = extract('task-contract-drift-case'); // do not trim, preserve indentation
let summary = extract('start-summary');
// Remove surrounding quotes if present; preserve internal \n escapes as literal characters
if (summary.startsWith('"') && summary.endsWith('"')) summary = summary.slice(1, -1);

writeFileSync('/tmp/P84-T1/code-pact/src/commands/task-progress.ts', tp);

let taskTs = readFileSync('/tmp/P84-T1/code-pact/src/cli/commands/task.ts', 'utf8');
const insertBefore = '    // Control-plane integrity error from the shared resolver / plan-state loaders.\n    case "PHASE_SNAPSHOT_INVALID":';
if (!taskTs.includes(insertBefore)) throw new Error('PHASE_SNAPSHOT_INVALID anchor not found');
// The driftCase already has 4-space indentation; insert a blank line before for readability? Keep exact.
taskTs = taskTs.replace(insertBefore, driftCase + '\n' + insertBefore);
writeFileSync('/tmp/P84-T1/code-pact/src/cli/commands/task.ts', taskTs);

let taskSpec = readFileSync('/tmp/P84-T1/code-pact/src/cli/spec/task.ts', 'utf8');
// Replace the summary array for the start command with the new string literal.
// Match `summary: [` ... `].join("\\n")` within const start block.
const summaryRe = /(const start: CommandSpec = \{[\s\S]*?summary:\s*)\[[\s\S]*?\]\.join\("\\n"\)/;
if (!summaryRe.test(taskSpec)) throw new Error('start summary not found');
taskSpec = taskSpec.replace(summaryRe, `$1${summary}`);
writeFileSync('/tmp/P84-T1/code-pact/src/cli/spec/task.ts', taskSpec);

console.log('applied v2');
