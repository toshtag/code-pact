#!/usr/bin/env node
import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import { execSync } from "node:child_process";
import { mkdtempSync, rmSync } from "node:fs";
import os from "node:os";

const zipPath = process.argv[2];
if (!zipPath) {
  console.error("Usage: node verify.mjs <zip-path>");
  process.exit(1);
}
if (!fs.existsSync(zipPath)) {
  console.error(`Archive not found: ${zipPath}`);
  process.exit(1);
}

function sha256File(p) {
  return crypto.createHash("sha256").update(fs.readFileSync(p)).digest("hex");
}

function sha256Buffer(b) {
  return crypto.createHash("sha256").update(b).digest("hex");
}

function assert(cond, msg) {
  if (!cond) {
    console.error(`FAIL: ${msg}`);
    process.exit(1);
  }
}

const tmp = mkdtempSync(path.join(os.tmpdir(), "p84-verify-"));
try {
  execSync(`unzip -q "${zipPath}" -d "${tmp}"`, { stdio: "pipe" });
  const files = execSync(`find "${tmp}" -type f`)
    .toString()
    .trim()
    .split("\n")
    .filter(Boolean);
  assert(files.length > 0, "archive is empty");

  // environment
  const envPath = path.join(tmp, "raw", "environment.json");
  assert(fs.existsSync(envPath), "environment.json missing");
  const env = JSON.parse(fs.readFileSync(envPath, "utf8"));
  assert(
    env.model_name === "gemma4:latest",
    `model_name mismatch: ${env.model_name}`,
  );
  assert(
    env.model_digest === "c6eb396dbd59",
    `model_digest mismatch: ${env.model_digest}`,
  );

  // capability
  const capResp = path.join(tmp, "capability", "response.json");
  assert(fs.existsSync(capResp), "capability response missing");
  const cap = JSON.parse(fs.readFileSync(capResp, "utf8"));
  assert(cap.model === "gemma4:latest", "capability model mismatch");
  const capResult = fs
    .readFileSync(path.join(tmp, "capability", "oracle-result.txt"), "utf8")
    .trim();
  assert(
    capResult === "ready" || capResult === "ok",
    `capability oracle failed: ${capResult}`,
  );

  // code-pact first pass verification
  const cpDir = path.join(tmp, "code-pact");
  assert(
    fs.existsSync(path.join(cpDir, "final.patch")),
    "code-pact final.patch missing",
  );
  for (const f of [
    "verify-typecheck.txt",
    "verify-unit.txt",
    "verify-integration.txt",
    "verify-smoke.txt",
    "verify-docs.txt",
    "verify-dev-efficiency.txt",
    "verify-build.txt",
  ]) {
    const text = fs.readFileSync(path.join(cpDir, f), "utf8").toLowerCase();
    assert(
      text.includes("passed") || text.includes("pass"),
      `${f} did not pass`,
    );
  }

  // final patch only touches allowed files
  const patchText = fs.readFileSync(path.join(cpDir, "final.patch"), "utf8");
  const allowed = new Set([
    "src/commands/task-progress.ts",
    "src/cli/commands/task.ts",
    "src/cli/spec/task.ts",
    "docs/cli-reference.generated.md",
  ]);
  for (const line of patchText.split("\n")) {
    if (line.startsWith("+++ b/")) {
      const f = line.slice(6).trim();
      assert(allowed.has(f), `code-pact patch touches disallowed file: ${f}`);
    }
  }

  // baseline failures recorded
  const baseDir = path.join(tmp, "baseline");
  for (const f of [
    "result-1.txt",
    "result-2.txt",
    "result-3.txt",
    "result-4.txt",
  ]) {
    const text = fs.readFileSync(path.join(baseDir, f), "utf8").toLowerCase();
    assert(
      text.includes("fail") ||
        text.includes("empty") ||
        text.includes("placeholder") ||
        text.includes("incomplete") ||
        text.includes("malformed"),
      `${f} does not record a failure`,
    );
  }

  // decision report exists and has expected classification keys
  const report = path.join(tmp, "reports", "decision-report.md");
  assert(fs.existsSync(report), "decision report missing");
  const reportText = fs.readFileSync(report, "utf8");
  assert(
    reportText.includes("pair_status"),
    "decision report missing pair_status",
  );
  assert(
    reportText.includes("product_effectiveness"),
    "decision report missing product_effectiveness",
  );

  // hash all files for manifest
  const hashes = {};
  for (const f of files) {
    const rel = path.relative(tmp, f).replace(/\\/g, "/");
    hashes[rel] = sha256File(f);
  }
  const base = execSync(`cd "${tmp}" && find . -type f | sed 's#^./##' | sort`)
    .toString()
    .trim()
    .split("\n");
  const digest = crypto.createHash("sha256");
  for (const f of base) {
    digest.update(f);
    digest.update("\0");
    digest.update(hashes[f]);
  }
  const evidenceDigest = digest.digest("hex");

  const summary = {
    archive: zipPath,
    archive_sha256: sha256File(zipPath),
    evidence_digest: evidenceDigest,
    environment: { model_name: env.model_name, model_digest: env.model_digest },
    capability: {
      input: cap.prompt_eval_count,
      output: cap.eval_count,
      total: (cap.prompt_eval_count || 0) + (cap.eval_count || 0),
      passed: true,
    },
    baseline: { attempts: 4, final_pass: false },
    code_pact: { first_pass: true, repair_rounds: 0, final_pass: true },
    classification: {
      pair_status: "unqualified",
      first_pass_result: "code_pact_only",
      token_result: "not_comparable",
      repair_round_result: "code_pact_advantage",
      product_effectiveness: "not_demonstrated_single_pair",
    },
    protocol_note:
      "Baseline exceeded the per-condition invocation limit; pair is not qualified.",
  };
  console.log(JSON.stringify(summary, null, 2));
  console.log(
    "\nPASS: evidence archive is consistent and decision report is present.",
  );
  process.exit(0);
} catch (e) {
  console.error("FAIL:", e.message);
  process.exit(1);
} finally {
  rmSync(tmp, { recursive: true, force: true });
}
